# TotalRecalls — Local Vector Search & SQL Container

**Installed:** 2026-10-26 on the Mini-PC (Intel i9-9880H, 64 GB RAM, Windows 10 19045)
**Updated:** 2026-10-27 — all eight providers now indexed
**Root:** `C:\TotalRecalls-Search\`

Everything below runs 100% offline. No cloud service, no third-party processing.

**The user guide** is `docs\TotalRecalls-Power-User-Guide.pdf`. It is self-contained
and covers setup, querying, the chat interface, Obsidian and Notion integration,
and maintenance. This file is the technical record behind it.

---

## 1. What was built

| Component | Location | Technology |
|---|---|---|
| SQLite metadata container | `C:\TotalRecalls-Search\data\totalrecalls_chats.db` | stdlib `sqlite3` |
| Vector index | `C:\TotalRecalls-Search\vector_store\ai_knowledge_base.lance` | LanceDB + all-MiniLM-L6-v2 |
| SQL builder | `scripts\build_sql_container.py` | Python |
| Vector builder | `scripts\build_vector_index.py` | sentence-transformers |
| Search CLI | `scripts\search_my_ai.py` | sentence-transformers |
| Chat UI + API | `scripts\chat_server.py` | retrieval + LM Studio |
| Notion exporter | `scripts\export_for_notion.py` | Markdown / Notion API |
| Re-index | `scripts\reindex_all.py` + task `TotalRecalls-ReIndex` | Task Scheduler |
| Task installer | `scripts\install_task.py` | Task Scheduler |
| Verification | `scripts\verify_install.py`, `scripts\test_suite.py` | Python |
| Isolated env | `C:\TotalRecalls-Search\venv\` | Python 3.14.9 |

### Indexed content — all eight providers

**415 conversations, 8,265 messages** from `C:\TotalRecalls-Downloads\Library\`

| Provider | Conversations |
|---|---:|
| chatgpt | 106 |
| perplexity | 90 |
| gemini | 86 |
| deepseek | 45 |
| claude | 39 |
| qwen | 25 |
| grok | 21 |
| mistral | 3 |

Vector index: **43,633 chunks** at 384 dimensions. Chunks are 500-char windows
with 50-char overlap so sentences are never split mid-thought.

---

## 2. Corrections to the original memo

The memo is a marketing blueprint with placeholder paths and scripts that do not
run against real TotalRecalls exports. This implementation fixes five things:

**a) Wrong paths.** The memo hardcodes `C:\TotalRecalls\Library` and
`C:\TotalRecalls\vector_store`. Neither exists. The real export root is
`C:\TotalRecalls-Downloads\Library`. Everything here points at the real path.

**b) Wrong JSON schema.** The memo's Step 2 script reads `data['id']`,
`data['provider']`, `data['title']` at the top level. Real files nest all of that
under `data['conversation']`:

```json
{"schema_version":1,"provider":"claude","account":{...},
 "conversation":{"id":"...","title":"...","created_at":"...","messages":[...]}}
```

Running the memo's script against this library raises `KeyError: 'id'`.

**c) Empty Qwen IDs.** All 25 qwen exports have `conversation.id == ""`.
The memo uses `id TEXT PRIMARY KEY`, which would collapse all 25 qwen
conversations into a single row. This build keys each conversation on
`provider/<folder>/<conversation-dir>` instead — verified: 25 distinct rows.

**d) Docker is unnecessary.** LanceDB and SQLite are in-process Python libraries.
A container adds nothing here, and Docker is not installed on this machine.
The memo's "container" language is marketing, not a technical requirement.

**e) Qwen exports are defective at the source.** Every one of the 25 qwen
conversation directories is named `... -- 00000000` and every
`conversation.json` has `"id": ""`. The exporter failed to resolve the qwen
conversation id and wrote zeros instead. Two consequences for the app itself:
qwen conversations cannot be uniquely identified by id, and the folder name
carries no hash. This build works around it by keying on the directory path
(the `YYYY-MM-DD HH-MM` prefix is unique) and by stripping the `00000000`
artifact from display labels. The underlying exporter bug is in the TotalRecalls
app, not in this search layer — worth fixing at the source so future exports
carry real ids.

Also fixed: the memo's 500-char chunks split sentences mid-thought. This build
uses the same 500-char window but with 50-char overlap.

---

## 3. Export layout is not fixed

Discovery (`scripts\tr_discovery.py`) walks the whole library tree and finds every
`conversation.json`, so all three of these real layouts work:

```
Library/<provider>/<folder>/<conv-dir>/conversation.json   (current)
Library/<provider>/<conv>.json + <conv>.md                 (flat, memo's snapshot)
Library/<provider>/<folder>/<sub>/<conv-dir>/...           (Gemini takeout)
```

A hardcoded `provider/*/*/conversation.md` glob would silently drop any provider
arriving in a different layout — with no error. Discovery is layout-agnostic and
de-duplicates on absolute `json_path`. Adding a provider requires no code change.

---

## 4. Verification record

Every claim above was checked against the running system, not assumed.

| Check | Result |
|---|---|
| Package imports (torch, lancedb, sentence-transformers, pandas, numpy) | PASS |
| SQLite chats == library conversation dirs | 415 == 415 |
| Qwen rows distinct (empty-id trap) | 25 rows / 25 keys |
| Every non-empty chat has messages | 0 orphans |
| SQL re-run idempotency | 415 / 8,265 unchanged |
| SQL picks up a new export (test) | 260 -> 261 chats, 5,826 -> 5,828 msgs |
| Vector re-run idempotency (3x) | 89 rows, 0 duplicates |
| Vector picks up new conversations (5 -> 9 files) | 89 -> 106 rows, +17, 0 duplicates |
| **All 8 providers indexed by both containers** | **415 chats, 43,633 chunks** |
| **8-provider simulation (all layouts)** | **8/8 in both builders** |
| Vector chunks trace back to real files on disk | 415 paths |
| Live semantic query returns real content | PASS |
| Chat retrieval spans multiple providers | PASS |
| Scheduled task registers and repeats (P1D) | PASS |
| Automated test suite | 37 assertions, 0 failures |

### 8-provider simulation

Before the four remaining providers were exported, discovery was verified against
a synthetic library containing all **8** providers in **three different layouts**,
then run through the real builders:

```
SQL builder   -> 16 conversations, 32 messages, 8/8 providers
Vector builder-> 16 conversations,  64 chunks, 8/8 providers
```

Layouts covered: `provider/folder/conv/` (current), `provider/folder/sub/conv/`
(Gemini takeout style), and `provider/<file>.json + .md` (flat). The builders
print `[COVERAGE] N/8` and name any pending providers.

Re-run the checks any time:

```bat
venv\Scripts\python.exe scripts\verify_install.py
venv\Scripts\python.exe scripts\test_suite.py
```

---

## 5. Usage

```bat
:: natural-language search across every provider
venv\Scripts\python.exe scripts\search_my_ai.py "asynchronous queue worker error handling"

:: more results, one provider only
venv\Scripts\python.exe scripts\search_my_ai.py "sierra chart reversal alert" --limit 8 --provider perplexity

:: also pull SQL metadata hits (title + message content LIKE)
venv\Scripts\python.exe scripts\search_my_ai.py "prop firm rules" --sql

:: query the SQLite container directly
venv\Scripts\python.exe -c "import sqlite3;c=sqlite3.connect(r'C:\TotalRecalls-Search\data\totalrecalls_chats.db');print(c.execute('SELECT provider,COUNT(*) FROM chats GROUP BY provider').fetchall())"

:: chat with your archive (LM Studio running locally)
venv\Scripts\python.exe scripts\chat_server.py
:: then open http://localhost:8000

:: export the archive for Notion
venv\Scripts\python.exe scripts\export_for_notion.py
```

### SQL schema

```sql
chats(row_pk, conv_key UNIQUE, provider, folder, title, conv_label, occurred_at,
      created_at, updated_at, message_count, char_count, json_path, md_path)
messages(message_pk, conv_key, ordinal, role, model, created_at,
         char_count, external_id, content_md)
meta(key, value)   -- schema_version, built_at, library_root
```

`conv_key` joins the two tables. Indexes on `provider`, `created_at`, and
`(conv_key, ordinal)`.

### Relational queries (the point of the SQL layer)

```sql
-- date-range filtering
SELECT provider, COUNT(*) FROM chats WHERE created_at >= '2026-01-01'
GROUP BY provider ORDER BY 2 DESC;

-- per-provider engagement
SELECT provider, COUNT(*), ROUND(AVG(message_count),1)
FROM chats GROUP BY provider ORDER BY 3 DESC;

-- message-level analysis
SELECT role, COUNT(*) FROM messages GROUP BY role;
SELECT model, COUNT(*) FROM messages WHERE model != '' GROUP BY model ORDER BY 2 DESC;

-- join: every message with its conversation title
SELECT c.title, m.role, substr(m.content_md,1,80)
FROM chats c JOIN messages m ON m.conv_key = c.conv_key
WHERE c.provider = 'perplexity';
```

---

## 6. Maintenance

**Automatic re-index:** scheduled task `TotalRecalls-ReIndex` runs
`scripts\reindex_all.py`. The schedule is user-selectable; the **default is once
every 24 hours at 3:00 a.m.**

```bat
venv\Scripts\python.exe scripts\install_task.py                  :: default 24h @ 03:00
venv\Scripts\python.exe scripts\install_task.py --interval-hours 12
venv\Scripts\python.exe scripts\install_task.py --weekly --day Sunday
venv\Scripts\python.exe scripts\install_task.py --at 22:30
venv\Scripts\python.exe scripts\install_task.py --disable
venv\Scripts\python.exe scripts\install_task.py --show
```

Both builders are idempotent — SQL upserts, and the vector builder merges only
unseen `chunk_id` values, so a re-run does not duplicate work.

Verified: three consecutive re-index runs left the row count unchanged with
zero duplicate `chunk_id` values, and a wider re-run (5 -> 9 files) added only
the new conversations (89 -> 106 rows, +17, 0 duplicates). The SQL builder
picks up new exports the same way: adding one synthetic conversation to a copy
of the library took the DB from 260 -> 261 chats and 5,826 -> 5,828 messages.
(The 260/5,826 figures in this section are the sizes recorded when those tests
were run, before the remaining four providers were exported.)

### Task Scheduler pitfalls found

- **`New-ScheduledTaskTrigger -At 03:00` pins `StartBoundary` to *today's*
  date.** If that time has already passed, the first run is silently deferred a
  full week — no error, no log. The installer anchors the trigger to the next real
  occurrence instead.
- **`[TimeSpan]::MaxValue` serializes to `P99999999DT23H59M59S`**, which Task
  Scheduler rejects as out of range (`0x80041318`). Use a bounded duration.
- **`Register-ScheduledTask` fails with `ResourceExists`** if the task is already
  registered. The installer unregisters first.
- **`New-ScheduledTaskRepetitionPattern` is not a cmdlet.** `-RepetitionInterval`
  and `-RepetitionDuration` are parameters of `New-ScheduledTaskTrigger` itself.

**Manual re-index:**
```bat
venv\Scripts\python.exe scripts\reindex_all.py
```

**Full rebuild from scratch:**
```bat
venv\Scripts\python.exe scripts\build_sql_container.py --rebuild
venv\Scripts\python.exe scripts\build_vector_index.py --overwrite
```

Logs: `C:\TotalRecalls-Search\reindex_log.txt`

---

## 7. Obsidian integration

Point an Obsidian vault at `C:\TotalRecalls-Downloads\Library`. All eight provider
folders appear as native Markdown notes with full graph connectivity — the files
are already plain Markdown, so no conversion is needed. Obsidian is not installed
on this machine, so this was documented but not configured locally.

## 8. Notion integration

`scripts\export_for_notion.py` writes one Markdown file per conversation under
`notion_export\<provider>\`, plus an index. Import that folder into Notion
(Import → Markdown & CSV) and each conversation becomes a page. The same script
can push pages via the Notion API (`--to-api --token ... --parent-page ...`) for
an automatically-updating mirror.

Verified: 415 pages written across 8 provider folders.

---

## 9. Fresh setup

`setup.bat` in the package root does the whole thing: creates the venv, installs
packages, builds both containers, and registers the re-index task.

```bat
:: 1. create the environment
python -m venv C:\TotalRecalls-Search\venv

:: 2. install dependencies
C:\TotalRecalls-Search\venv\Scripts\python.exe -m pip install -r C:\TotalRecalls-Search\requirements.txt

:: 3. build both indexes
C:\TotalRecalls-Search\venv\Scripts\python.exe C:\TotalRecalls-Search\scripts\build_sql_container.py
C:\TotalRecalls-Search\venv\Scripts\python.exe C:\TotalRecalls-Search\scripts\build_vector_index.py

:: 4. register the automatic re-index
C:\TotalRecalls-Search\venv\Scripts\python.exe C:\TotalRecalls-Search\scripts\install_task.py
```

The embedding model (~400 MB) downloads on first use from HuggingFace and is
cached at `%USERPROFILE%\.cache\huggingface\` — it does not re-download.

## 10. Known issues

| Issue | Detail |
|---|---|
| **Qwen export defect** (in the app) | All qwen exports have an empty `conversation.id` and directory suffix `00000000`. Worked around here by keying on path; the fix belongs in the exporter. |
| **One empty conversation** | A grok conversation (`2026-01-12 ... nfl game`) is genuinely empty — `"responses": []` in the raw data. Legitimate data, not a parse failure. |
| **Local model may be unusable on CPU-only hardware** | The chat interface's *retrieval* works everywhere. Its *generation* needs a local model that can actually run on the machine. A 30B model on CPU-only hardware is impractically slow in the LM Studio UI; the API path worked only for a very short completion. `chat_server.py --no-llm` gives a retrieval-only chat that needs no model at all. |
| **LM Studio unloads models** | LM Studio unloads the model when idle, so the next request waits for a reload. Keep the model loaded, or expect a delay on first use. |
| **lancedb 0.40 API** | `table_names()` is deprecated; `list_tables()` returns a response object, not a list. `to_lance()` needs the optional `pylance` package — the native `table.search(vec).limit(n).to_list()` is used instead. |
