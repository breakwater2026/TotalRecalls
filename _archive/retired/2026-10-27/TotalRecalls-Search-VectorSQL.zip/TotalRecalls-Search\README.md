# TotalRecalls — Local Vector Search & SQL Container

Private, 100% offline semantic search + SQL metadata over your TotalRecalls
exports. Nothing is sent to any cloud or third-party service.

**Start with the guide:** `docs/TotalRecalls-Power-User-Guide.pdf` — it is
self-contained and covers setup, querying, the chat interface, Obsidian and
Notion integration, and maintenance.

## What's here

| Path | Purpose |
|---|---|
| `venv/` | Isolated Python environment (do not delete) |
| `scripts/build_sql_container.py` | Parse every `conversation.json` into SQLite |
| `scripts/build_vector_index.py` | Embed every `conversation.md` into LanceDB |
| `scripts/search_my_ai.py` | Natural-language cross-provider search |
| `scripts/chat_server.py` | Local chat UI + OpenAI-compatible API |
| `scripts/export_for_notion.py` | Export the archive for Notion |
| `scripts/reindex_all.py` | Re-run both indexes (used by the scheduled task) |
| `scripts/install_task.py` | Set up or change the automatic re-index schedule |
| `scripts/tr_discovery.py` | Shared provider/conversation discovery (all layouts) |
| `scripts/verify_install.py` | Full end-to-end verification |
| `scripts/test_suite.py` | Automated assertions over the system |
| `docs/` | The user guide (PDF + build script) |
| `data/totalrecalls_chats.db` | SQLite container (`chats` + `messages` tables) |
| `vector_store/ai_knowledge_base.lance` | LanceDB vector index (384-dim embeddings) |
| `notion_export/` | Generated Notion pages (created when you export) |
| `reindex_log.txt` | Scheduled-task log |
| `INSTALL-NOTES.md` | Full install record and schema documentation |

## Data source

`C:\TotalRecalls-Downloads\Library\` — discovery is layout-agnostic and walks the
whole tree, so any nesting works:

```
Library/<provider>/<folder>/<conversation-dir>/conversation.json   (current)
Library/<provider>/<conversation>.json  +  <conversation>.md      (flat)
Library/<provider>/<folder>/<sub>/<conversation-dir>/...           (takeout)
```

Adding a provider requires **no code change**: export it, then run the reindex.

## Indexed content — all 8 providers

**415 conversations, 8,265 messages** · vector index: 43,633 chunks × 384 dims

| Provider | Conversations | Status |
|---|---:|---|
| chatgpt | 106 | ✅ indexed |
| perplexity | 90 | ✅ indexed |
| gemini | 86 | ✅ indexed |
| deepseek | 45 | ✅ indexed |
| claude | 39 | ✅ indexed |
| qwen | 25 | ✅ indexed |
| grok | 21 | ✅ indexed |
| mistral | 3 | ✅ indexed |

## Quick start

```bat
:: build both containers
venv\Scripts\python.exe scripts\build_sql_container.py
venv\Scripts\python.exe scripts\build_vector_index.py

:: search
venv\Scripts\python.exe scripts\search_my_ai.py "sierra chart reversal alert"

:: chat with your archive (LM Studio running locally)
venv\Scripts\python.exe scripts\chat_server.py
:: then open http://localhost:8000

:: export for Notion
venv\Scripts\python.exe scripts\export_for_notion.py

:: automatic re-index: every 24 hours at 03:00 (the default)
venv\Scripts\python.exe scripts\install_task.py
```

## Verify

```bat
venv\Scripts\python.exe scripts\verify_install.py   :: checks the live install
venv\Scripts\python.exe scripts\test_suite.py       :: 37 assertions on synthetic data
```

## Maintenance

The scheduled task `TotalRecalls-ReIndex` runs `scripts\reindex_all.py` on a
schedule you choose — **default: every 24 hours at 3:00 a.m.** Both builders are
idempotent: the SQL builder upserts, and the vector builder merges only unseen
`chunk_id` values, so a re-run does not duplicate work.

```bat
venv\Scripts\python.exe scripts\install_task.py                  :: default 24h @ 03:00
venv\Scripts\python.exe scripts\install_task.py --interval-hours 12
venv\Scripts\python.exe scripts\install_task.py --weekly --day Sunday
venv\Scripts\python.exe scripts\install_task.py --at 22:30
venv\Scripts\python.exe scripts\install_task.py --disable
venv\Scripts\python.exe scripts\install_task.py --show
```

Manual re-index:

```bat
venv\Scripts\python.exe scripts\reindex_all.py
```

## Connecting to other tools

- **Obsidian** — point a vault at `C:\TotalRecalls-Downloads\Library`. The eight
  provider folders appear as native Markdown notes with full graph connectivity.
- **Notion** — run `scripts\export_for_notion.py`, then import the generated
  folder (Markdown & CSV). One page per conversation, grouped by provider.
- **Any OpenAI-compatible client** — point it at `http://localhost:8000/v1` while
  `chat_server.py` is running.
