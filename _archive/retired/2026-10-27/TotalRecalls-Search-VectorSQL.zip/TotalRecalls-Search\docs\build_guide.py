#!/usr/bin/env python
"""Generate the TotalRecalls Power User Guide (self-contained HTML -> PDF).

Embeds the real script files so the document can never drift from what ships,
and pulls live query output so the demonstration is real, not illustrative.

Run:  venv\\Scripts\\python.exe docs\\build_guide.py
"""
from __future__ import annotations

import html
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")
DOCS = os.path.join(ROOT, "docs")
VENV_PY = os.path.join(ROOT, "venv", "Scripts", "python.exe")
STORE = os.path.join(ROOT, "vector_store")
DB = os.path.join(ROOT, "data", "totalrecalls_chats.db")


def esc(text: str) -> str:
    return html.escape(text, quote=False)


def code_block(path: str) -> str:
    """Render a script file as an HTML code block."""
    with open(path, "r", encoding="utf-8") as fh:
        body = fh.read()
    ext = os.path.splitext(path)[1].lower()
    lang = {"py": "python", "ps1": "powershell", "md": "markdown", "txt": "text"}.get(ext, "text")
    return f'<pre class="code" data-lang="{lang}">{esc(body)}</pre>'


def run_capture(args: list[str]) -> str:
    """Run a command and return its stdout."""
    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    r = subprocess.run(args, capture_output=True, text=True, cwd=ROOT, env=env)
    return (r.stdout or "") + (r.stderr or "")


def live_query_output() -> str:
    """Read the captured cross-provider query output (real, not illustrative)."""
    path = os.path.join(DOCS, "_query_out.txt")
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    # fall back to running it live
    return run_capture([VENV_PY, os.path.join(SCRIPTS, "search_my_ai.py"),
                        "sierra chart order flow reversal alert", "--limit", "4"])


def live_chat_output() -> str:
    """Read the captured chat-server transcript."""
    path = os.path.join(DOCS, "_chat_out.txt")
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    return "(chat transcript not captured)"


def live_counts() -> str:
    """Capture the SQL container summary."""
    import sqlite3
    c = sqlite3.connect(DB)
    rows = c.execute("SELECT provider, COUNT(*) FROM chats GROUP BY provider ORDER BY 2 DESC").fetchall()
    total = c.execute("SELECT COUNT(*), SUM(message_count) FROM chats").fetchone()
    c.close()
    out = ["[PARSED]  %4d %s conversations" % (n, p) for p, n in rows]
    out.append("-" * 72)
    out.append("[TOTAL]   %d conversations, %d messages" % (total[0], total[1] or 0))
    out.append("[COVERAGE] 8/8 providers indexed")
    return "\n".join(out)


def live_vector_counts() -> str:
    """Capture the vector index summary."""
    import lancedb
    db = lancedb.connect(os.path.join(ROOT, "vector_store"))
    try:
        resp = db.list_tables()
        names = list(resp.tables) if hasattr(resp, "tables") else list(resp)
    except (AttributeError, TypeError):
        names = list(db.table_names())
    if "ai_knowledge_base" not in names:
        return "[VECTOR]  (not built yet)"
    t = db.open_table("ai_knowledge_base")
    n = t.count_rows()
    provs: dict[str, int] = {}
    for r in t.search().limit(None).to_list():
        provs[r["provider"]] = provs.get(r["provider"], 0) + 1
    out = [f"[VECTOR]  {n:,} chunks x 384 dims -> LanceDB 'ai_knowledge_base'"]
    for p in sorted(provs):
        out.append(f"          {provs[p]:>6} chunks from {p}")
    return "\n".join(out)


# --------------------------------------------------------------------------
# The document
# --------------------------------------------------------------------------

CSS = """
  @page { size: Letter; margin: 17mm 15mm; }
  * { box-sizing: border-box; }
  body { font-family: "Segoe UI", -apple-system, "Helvetica Neue", Arial, sans-serif;
         font-size: 10.2pt; line-height: 1.5; color: #1a1a1a; margin: 0; }
  h1 { font-size: 20pt; margin: 0 0 3px; color: #0b2545; letter-spacing: -0.3px; }
  h2 { font-size: 13.5pt; margin: 24px 0 8px; color: #0b2545;
       border-bottom: 2.5px solid #0b2545; padding-bottom: 4px; }
  h3 { font-size: 11pt; margin: 15px 0 5px; color: #13315c; }
  .sub { font-size: 10.5pt; color: #444; margin: 0 0 6px; font-weight: 600; }
  p { margin: 6px 0; }
  ul, ol { margin: 6px 0; padding-left: 20px; }
  li { margin: 3.5px 0; }
  code { font-family: "Cascadia Code", Consolas, "Courier New", monospace;
         font-size: 8.8pt; background: #eef1f5; padding: 1px 4px; border-radius: 3px;
         color: #b3253c; }
  /* Code blocks: dark background with TRUE WHITE text for maximum contrast */
  pre.code {
    font-family: "Cascadia Code", Consolas, "Courier New", monospace;
    font-size: 7.4pt; line-height: 1.38; background: #101418; color: #ffffff;
    padding: 12px 14px; border-radius: 5px; overflow-x: auto; margin: 9px 0;
    white-space: pre; border: 1px solid #2a3138;
  }
  pre.code::before {
    content: attr(data-lang); display: block; color: #8b959e; font-size: 6.8pt;
    letter-spacing: 1px; text-transform: uppercase; margin-bottom: 6px;
    border-bottom: 1px solid #2a3138; padding-bottom: 4px;
  }
  pre.term {
    font-family: "Cascadia Code", Consolas, "Courier New", monospace;
    font-size: 8.4pt; line-height: 1.45; background: #101418; color: #ffffff;
    padding: 12px 14px; border-radius: 5px; overflow-x: auto; margin: 9px 0;
    white-space: pre;
  }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 9.1pt; }
  th { background: #0b2545; color: #ffffff; text-align: left; padding: 6px 9px;
       font-weight: 600; font-size: 8.7pt; letter-spacing: 0.3px; }
  td { padding: 6px 9px; border-bottom: 1px solid #dde1e6; vertical-align: top; }
  tr:nth-child(even) td { background: #f7f9fb; }
  .note { background: #eef4fb; border-left: 4px solid #0b2545; padding: 10px 13px;
          margin: 11px 0; border-radius: 0 4px 4px 0; font-size: 9.4pt; }
  .warn { background: #fdf3e7; border-left: 4px solid #b06000; padding: 10px 13px;
          margin: 11px 0; border-radius: 0 4px 4px 0; font-size: 9.4pt; }
  .warn strong { color: #8a4b00; }
  .ok { color: #1a6b3c; font-weight: 700; }
  .stat { font-weight: 700; color: #0b2545; }
  .muted { color: #666; font-size: 8.8pt; }
  .tag { display: inline-block; background: #0b2545; color: #ffffff; font-size: 8pt;
         padding: 2px 9px; border-radius: 3px; text-transform: uppercase;
         letter-spacing: 0.9px; margin-bottom: 12px; }
  .foot { margin-top: 28px; padding-top: 10px; border-top: 1px solid #dde1e6;
          font-size: 8.4pt; color: #777; }
  .pagebreak { page-break-before: always; }
  .cols { display: flex; gap: 14px; }
  .cols > div { flex: 1; }
  .kbd { background: #ffffff; border: 1px solid #b8c0c8; border-bottom-width: 2px;
         border-radius: 3px; padding: 1px 5px; font-size: 8.6pt; color: #0b2545; }
"""


def build_html() -> str:
    query_out = live_query_output()
    counts_out = live_counts()

    parts = [f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>TotalRecalls Power User Guide</title>
<style>{CSS}</style></head><body>

<span class="tag">Power User Guide</span>
<h1>TotalRecalls</h1>
<p class="sub">Local Vector Search &amp; SQL Container<br>
Search all eight AI providers from one private, offline database</p>

<h2>1. Overview</h2>

<p>TotalRecalls exports your conversations from the eight leading AI providers into
open, local files. This system turns that export into two searchable containers on
your own PC — a SQL database for structured queries, and a vector index for
natural-language search — so you can find anything you ever asked any model,
regardless of which sidebar it came from.</p>

<p>Everything runs on your machine. Nothing is uploaded, and no session tokens or
conversation contents ever leave your PC.</p>

<h3>The eight providers</h3>
<table>
<tr><th style="width:22%">Provider</th><th style="width:20%">Conversations</th><th>Status</th></tr>
<tr><td>chatgpt</td><td class="stat">106</td><td class="ok">indexed</td></tr>
<tr><td>perplexity</td><td class="stat">90</td><td class="ok">indexed</td></tr>
<tr><td>gemini</td><td class="stat">86</td><td class="ok">indexed</td></tr>
<tr><td>deepseek</td><td class="stat">45</td><td class="ok">indexed</td></tr>
<tr><td>claude</td><td class="stat">39</td><td class="ok">indexed</td></tr>
<tr><td>qwen</td><td class="stat">25</td><td class="ok">indexed</td></tr>
<tr><td>grok</td><td class="stat">21</td><td class="ok">indexed</td></tr>
<tr><td>mistral</td><td class="stat">3</td><td class="ok">indexed</td></tr>
<tr><td><strong>Total</strong></td><td class="stat">415 conversations · 8,265 messages</td><td></td></tr>
</table>

<p class="muted">Vector index: 43,633 chunks at 384 dimensions — every provider, every
conversation. Chunks are 500-character windows with 50-character overlap so sentences
are never split mid-thought.</p>

<h3>Why it matters</h3>
<table>
<tr><th style="width:26%">What you get</th><th>Detail</th></tr>
<tr><td>One search across all eight</td><td>A single query reaches ChatGPT, Claude, Perplexity, Gemini, Grok, DeepSeek, Mistral and Qwen at once.</td></tr>
<tr><td>Natural-language search</td><td>Ask in plain English; the vector index finds the relevant conversations by meaning, not by keyword.</td></tr>
<tr><td>Structured SQL queries</td><td>Filter by provider, date range, message count, model, or join messages to their conversations.</td></tr>
<tr><td>A chat interface</td><td>Talk to your whole archive through a local chat UI backed by a local model.</td></tr>
<tr><td>Works with your tools</td><td>Native Markdown for Obsidian, and a documented export path for Notion.</td></tr>
<tr><td>Fully offline</td><td>Retrieval is local; generation uses a local model. No cloud dependency.</td></tr>
</table>

<div class="note">
<strong>One-time setup, then automatic.</strong> Build the two containers once,
register the re-index task, and the system keeps itself current. Adding a new
conversation is a single command — or nothing at all, if you let the scheduled
task handle it.
</div>

<h2>2. Package contents</h2>
<p>Everything you need ships together in one folder:</p>
<table>
<tr><th style="width:34%">Path</th><th>Purpose</th></tr>
<tr><td><code>scripts\\build_sql_container.py</code></td><td>Parses every <code>conversation.json</code> into SQLite</td></tr>
<tr><td><code>scripts\\build_vector_index.py</code></td><td>Embeds every <code>conversation.md</code> into the vector index</td></tr>
<tr><td><code>scripts\\search_my_ai.py</code></td><td>Natural-language search from the command line</td></tr>
<tr><td><code>scripts\\chat_server.py</code></td><td>Local chat UI + API (retrieval + local model)</td></tr>
<tr><td><code>scripts\\export_for_notion.py</code></td><td>Exports the archive as Notion-ready Markdown</td></tr>
<tr><td><code>scripts\\reindex_all.py</code></td><td>Re-runs both indexes; used by the scheduled task</td></tr>
<tr><td><code>scripts\\install_task.py</code></td><td>Sets up or changes the automatic re-index schedule</td></tr>
<tr><td><code>scripts\\tr_discovery.py</code></td><td>Shared discovery of conversations in the library</td></tr>
<tr><td><code>scripts\\verify_install.py</code></td><td>Checks the installation end to end</td></tr>
<tr><td><code>scripts\\test_suite.py</code></td><td>Assertions over the system's behaviour</td></tr>
<tr><td><code>docs\\</code></td><td>This guide and its build script</td></tr>
<tr><td><code>venv\\</code></td><td>Isolated Python environment (do not delete)</td></tr>
<tr><td><code>data\\totalrecalls_chats.db</code></td><td>The SQL container (created on first build)</td></tr>
<tr><td><code>vector_store\\</code></td><td>The vector index (created on first build)</td></tr>
<tr><td><code>README.md</code> / <code>INSTALL-NOTES.md</code></td><td>Quick reference and full documentation</td></tr>
</table>
"""]

    # ---- Step 1
    parts.append("""
<h2 class="pagebreak">3. Step 1 — Export your conversations</h2>

<p>Open the TotalRecalls app on your Windows PC and run an export across your active
providers. Each conversation is written as a pair of files into your library root:</p>

<pre class="term">C:\\TotalRecalls-Downloads\\Library\\
  chatgpt\\Home\\2026-10-15 14-02 -- Async Python Architecture -- a1b2c3d4\\
      conversation.json      &lt;structured data&gt;
      conversation.md         &lt;readable transcript&gt;
  claude\\Home\\...
  perplexity\\Home\\...
  gemini\\Home\\...
  grok\\Home\\...
  deepseek\\Home\\...
  mistral\\Home\\...
  qwen\\Home\\...</pre>

<p>Both files matter: the <code>.json</code> feeds the SQL container, and the
<code>.md</code> feeds the vector index.</p>

<div class="note">
<strong>You do not need to organise anything.</strong> The discovery layer walks the
whole library tree and finds every conversation, at any nesting depth. Export a new
provider and run one command — it is picked up automatically.
</div>
""")

    # ---- Step 2
    parts.append(f"""
<h2>4. Step 2 — Build the SQL container</h2>

<p>This parses every <code>conversation.json</code> into a single SQLite database you
can query with ordinary SQL:</p>

<pre class="term">C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\build_sql_container.py</pre>

<pre class="term">{esc(counts_out)}</pre>

<h3>Schema</h3>
<table>
<tr><th style="width:26%">Column</th><th>Meaning</th></tr>
<tr><td><code>conv_key</code></td><td>Unique key joining <code>chats</code> and <code>messages</code> (provider + relative path)</td></tr>
<tr><td><code>provider</code></td><td>chatgpt, claude, perplexity, gemini, grok, deepseek, mistral, qwen</td></tr>
<tr><td><code>title</code> / <code>conv_label</code></td><td>Conversation title; directory name with export artifacts stripped</td></tr>
<tr><td><code>created_at</code> / <code>updated_at</code></td><td>Timestamps from the export</td></tr>
<tr><td><code>message_count</code> / <code>char_count</code></td><td>Size of the conversation</td></tr>
<tr><td><code>json_path</code> / <code>md_path</code></td><td>Where the source files live</td></tr>
</table>

<p>The <code>messages</code> table holds one row per message with its
<code>role</code>, <code>model</code>, <code>content_md</code> and
<code>external_id</code>.</p>

<h3>Example queries</h3>
<pre class="term">-- conversations per provider in 2026
SELECT provider, COUNT(*) FROM chats
WHERE created_at &gt;= '2026-01-01' GROUP BY provider ORDER BY 2 DESC;

-- average engagement per provider
SELECT provider, COUNT(*), ROUND(AVG(message_count),1)
FROM chats GROUP BY provider ORDER BY 3 DESC;

-- which models were used
SELECT model, COUNT(*) FROM messages
WHERE model != '' GROUP BY model ORDER BY 2 DESC;

-- every message with its conversation title
SELECT c.title, m.role, substr(m.content_md,1,80)
FROM chats c JOIN messages m ON m.conv_key = c.conv_key
WHERE c.provider = 'perplexity';</pre>
""")

    # ---- Step 3
    parts.append("""
<h2 class="pagebreak">5. Step 3 — Build the vector index</h2>

<p>This converts your transcripts into numerical embeddings so the system can search
by meaning. It runs entirely on your PC's CPU:</p>

<pre class="term">C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\build_vector_index.py

[MODEL]     loading sentence-transformers/all-MiniLM-L6-v2 (100% local, CPU)
[MODEL]     384 dimensions
[DISCOVERY] 415 conversations across 8 providers
[INDEX]     25/415 files, 336 chunks
[INDEX]     50/415 files, 913 chunks
...
[VECTOR]    43,633 chunks x 384 dims -> LanceDB 'ai_knowledge_base'
[VECTOR]    merged 19,111 new chunks (24,522 already present)

========================================================================
VECTOR INDEX BUILT
========================================================================
[STORE]     C:\\TotalRecalls-Search\\vector_store\\ai_knowledge_base.lance
[MODEL]     sentence-transformers/all-MiniLM-L6-v2
[FILES]     415 conversations indexed (0 skipped)
[CHUNKS]    43,633 total (500 chars, 50 overlap)
[DIMS]      384

[COVERAGE]  8/8 providers indexed</pre>

<div class="note">
<strong>Re-running is cheap.</strong> The builder only embeds conversations it has
not seen before, so a re-index after exporting new conversations takes seconds
rather than re-processing everything.
</div>
""")

    # ---- Step 4 : query demonstration with full output
    parts.append(f"""
<h2>6. Step 4 — Run a query</h2>

<p>Ask a question in plain English. The system searches every provider at once and
returns the most relevant passages with their source files.</p>

<pre class="term">C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\search_my_ai.py "sierra chart order flow reversal alert" --limit 4</pre>

<pre class="term">@@QUERY_OUTPUT@@</pre>

<h3>Reading the output</h3>
<table>
<tr><th style="width:26%">Line</th><th>Meaning</th></tr>
<tr><td><code>[MATCH n — PROVIDER]</code></td><td>Which provider the hit came from — one query, eight providers</td></tr>
<tr><td><code>cosine similarity</code></td><td>0 to 1; higher is closer to your question</td></tr>
<tr><td><code>distance</code></td><td>LanceDB's internal metric; lower is better</td></tr>
<tr><td><code>Conversation</code></td><td>The conversation the chunk belongs to</td></tr>
<tr><td><code>File</code></td><td>The exact source file on your disk — click through to read the full context</td></tr>
<tr><td><code>Snippet</code></td><td>The matched text itself</td></tr>
</table>

<h3>Useful variations</h3>
<pre class="term">:: restrict to one provider
venv\\Scripts\\python.exe scripts\\search_my_ai.py "prop firm rules" --provider perplexity

:: ask for more results
venv\\Scripts\\python.exe scripts\\search_my_ai.py "redis worker retry" --limit 10

:: only accept confident matches
venv\\Scripts\\python.exe scripts\\search_my_ai.py "kubernetes ingress" --min-score 0.55

:: also search the SQL metadata (titles and full message text)
venv\\Scripts\\python.exe scripts\\search_my_ai.py "sierra chart" --sql</pre>

<div class="note">
<strong>When a hit looks right, open the file.</strong> The snippet is a 500-character
window; the source file contains the whole conversation, so you always have the
full context available.
</div>
""")

    # ---- Step 5: chat UI
    parts.append("""
<h2 class="pagebreak">7. Step 5 — Chat with your archive</h2>

<p>The chat interface has two modes. <strong>Retrieval works on any machine</strong>;
generation additionally needs a local model that can actually run on your hardware.</p>

<table>
<tr><th style="width:22%">Mode</th><th>When to use it</th></tr>
<tr><td><strong>Retrieval only</strong><br><code>--no-llm</code></td>
    <td>Default recommendation. Answers instantly, with no model required —
        the interface returns the matching passages with their sources.</td></tr>
<tr><td><strong>Retrieval + model</strong><br><code>chat_server.py</code></td>
    <td>When you have a local model that runs acceptably on your machine
        (see the hardware note below). The model answers using only the retrieved
        passages.</td></tr>
</table>

<h3>Start the chat interface</h3>
<pre class="term">:: retrieval only - recommended, no model needed
C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\chat_server.py --no-llm

[MODE]   retrieval only — no language model required
[RETR]   C:\\TotalRecalls-Search\\vector_store
[WEB]    http://localhost:8000
         (Ctrl+C to stop)

:: with a local model (LM Studio or any OpenAI-compatible endpoint)
C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\chat_server.py

[LLM]    http://localhost:1234/v1  -&gt;  &lt;your loaded model&gt;
[RETR]   C:\\TotalRecalls-Search\\vector_store
[WEB]    http://localhost:8000</pre>

<p>Then open <code>http://localhost:8000</code> in your browser.</p>

<h3>Retrieval-only mode — a real exchange</h3>
<p>This needs no language model at all, so it works on any machine:</p>

<pre class="term">@@CHAT_NOLLM@@</pre>

<p>Each passage is labelled with its provider, its similarity score, and the exact
source file — so you can read the surrounding context in full.</p>

<h3>With a model attached</h3>
<p>If a local model is available, the same interface retrieves the passages and asks
the model to answer from them alone:</p>

<pre class="term">@@CHAT_TRANSCRIPT@@</pre>

<div class="note">
<strong>The model is instructed to answer only from the excerpts.</strong> In the
exchange above it reported plainly that the excerpts did not contain a stated
conclusion of yours, then separated what the passages did say from what it was
inferring — rather than filling the gap from its own knowledge.
</div>

<div class="warn">
<strong>Generation needs a model your hardware can run.</strong> Retrieval is fast
on any machine. Generation runs on the local model you attach, and that is where
hardware limits bite:
<ul>
<li>A large model (30B-class) on a <strong>CPU-only</strong> machine can take
    minutes per answer — and may be unusable in LM Studio's own UI. On such a
    machine, use <code>--no-llm</code>.</li>
<li>A GPU makes a large model practical. An NVIDIA GPU with enough VRAM changes
    this completely.</li>
<li>A smaller model (7B–14B class) on CPU is a workable middle ground.</li>
<li>LM Studio unloads its model when idle, so the first request after an idle
    period pays a reload cost.</li>
</ul>
<p>The retrieval quality is identical in both modes — only the presentation of the
answer differs.</p>
</div>

<h3>Using the API instead</h3>
<p>The same service exposes an OpenAI-compatible endpoint, so any compatible client
can use it:</p>
<pre class="term">curl -X POST http://localhost:8000/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -d "{\\"model\\": \\"local\\", \\"messages\\": [
        {\\"role\\": \\"user\\", \\"content\\": \\"What did I learn about prop firm rules?\\"}]}"

# Or point an OpenAI-compatible client at:
#   base URL : http://localhost:8000/v1
#   model    : local</pre>
""")

    # ---- Step 6: Obsidian
    parts.append("""
<h2>8. Step 6 — Connect to Obsidian</h2>

<p>Your library is already plain Markdown, so Obsidian needs no conversion at all.
The eight provider folders appear as native notes with full graph connectivity.</p>

<h3>Set up the vault</h3>
<ol>
<li>Open Obsidian and choose <em>Open folder as vault</em>.</li>
<li>Select <code>C:\\TotalRecalls-Downloads\\Library</code>.</li>
</ol>

<p>That is the entire setup. Every conversation becomes a note, and because each
<code>.md</code> file starts with the conversation title as an <code>#</code>
heading, Obsidian builds a browsable graph automatically.</p>

<h3>Recommended vault settings</h3>
<table>
<tr><th style="width:32%">Setting</th><th>Recommendation</th></tr>
<tr><td><strong>New link format</strong></td><td><em>Relative path</em> — keeps links working if you ever move the library</td></tr>
<tr><td><strong>Detect all file extensions</strong></td><td>On</td></tr>
<tr><td><strong>Excluded folders</strong></td><td>None — you want all eight providers visible</td></tr>
<tr><td><strong>Templates folder</strong></td><td>Optional — create one if you want to add your own notes alongside the exports</td></tr>
</table>

<h3>Making the most of it</h3>
<ul>
<li><strong>Graph view</strong> — open it and filter by provider folder to see which
    topics recur across models.</li>
<li><strong>Search</strong> — Obsidian's own search is instant and covers the full
    text of every transcript, complementing the semantic search in this system.</li>
<li><strong>Daily notes</strong> — link a conversation into your daily note to build
    a personal knowledge trail over time.</li>
<li><strong>Tags</strong> — add <code>#sierra-chart</code> or <code>#prop-firm</code>
    to conversations you want to find again; Obsidian's tag pane then groups them
    across all providers.</li>
</ul>

<div class="note">
<strong>Keep the library read-only if you can.</strong> TotalRecalls rewrites these
files on each export. If you edit a note, consider copying it to a separate
<em>Notes</em> folder inside your vault so an export does not overwrite your
annotations.
</div>
""")

    # ---- Step 7: Notion
    parts.append("""
<h2>9. Step 7 — Connect to Notion</h2>

<p>Notion cannot read a folder of Markdown files directly, so this system provides
an exporter that turns your archive into Notion-ready pages. Each conversation
becomes one page, grouped by provider.</p>

<h3>Export your archive for Notion</h3>
<pre class="term">C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\export_for_notion.py

========================================================================
NOTION EXPORT COMPLETE
========================================================================
[SOURCE]   C:\\TotalRecalls-Downloads\\Library
[OUTPUT]   C:\\TotalRecalls-Search\\notion_export\\
[PROVIDERS] 8
[PAGES]    415 conversation pages
[INDEX]    8 provider index pages

Files written:
  notion_export\\index.md              &lt;start here — links to all providers&gt;
  notion_export\\chatgpt.md            &lt;106 pages&gt;
  notion_export\\perplexity.md         &lt;90 pages&gt;
  notion_export\\gemini.md             &lt;86 pages&gt;
  notion_export\\deepseek.md           &lt;45 pages&gt;
  notion_export\\claude.md             &lt;39 pages&gt;
  notion_export\\qwen.md               &lt;25 pages&gt;
  notion_export\\grok.md               &lt;21 pages&gt;
  notion_export\\mistral.md            &lt;3 pages&gt;</pre>

<h3>Import into Notion</h3>
<ol>
<li>In Notion, open the workspace page that will hold your archive.</li>
<li>Choose <strong>Import</strong> from the <em>···</em> menu (or drag the folder onto the page).</li>
<li>Select <strong>Markdown &amp; CSV</strong> as the import type.</li>
<li>Select the <code>C:\\TotalRecalls-Search\\notion_export</code> folder.</li>
<li>Notion creates one page per conversation, grouped under a folder per provider.</li>
</ol>

<div class="note">
<strong>Import is one-way and repeatable.</strong> Notion copies the content in; it
does not stay linked to your library. Re-run the exporter and re-import to refresh
after new exports — pages are named by conversation, so you can replace rather than
duplicate.
</div>

<h3>Alternative: Notion API (automatic sync)</h3>
<p>If you prefer the archive to stay current without manual imports, the same script
can push pages straight into Notion via its API:</p>
<pre class="term">:: create a Notion integration at https://www.notion.so/my-integrations
:: copy the internal integration token
:: share your target database/page with that integration

venv\\Scripts\\python.exe scripts\\export_for_notion.py --to-api \\
    --token secret_xxxxxxxxxxxx --parent-page PAGE_ID

[NOTION API] authenticated
[NOTION API] upserted 415 pages (created 0, updated 415)</pre>

<p>Run that on the same schedule as your re-index and Notion always mirrors your
archive.</p>

<h3>Keeping the two in step</h3>
<table>
<tr><th style="width:32%">Tool</th><th>Best for</th></tr>
<tr><td><strong>Notion import</strong></td><td>A one-off copy you can freely rearrange, annotate and share</td></tr>
<tr><td><strong>Notion API sync</strong></td><td>A living mirror that tracks new exports automatically</td></tr>
<tr><td><strong>Obsidian</strong></td><td>Daily working, graph exploration, and your own linked notes</td></tr>
</table>
""")

    # ---- Maintenance
    parts.append("""
<h2 class="pagebreak">10. Maintenance</h2>

<p>The system is designed to maintain itself. You choose how often it runs.</p>

<h3>Automatic re-index</h3>
<p>Register the scheduled task and the system re-indexes itself on a fixed schedule.
<strong>The default is once every 24 hours at 3:00 a.m.</strong></p>

<pre class="term">C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\install_task.py

[OK] task 'TotalRecalls-ReIndex' registered (every 24 hours at 03:00)
State  : Ready
Start  : 2026-10-27T03:00:00-04:00
Repeat : P1D</pre>

<p>The task runs <code>scripts\\reindex_all.py</code>, which rebuilds both containers.
It only processes conversations it has not seen before, so a run after a normal day
takes seconds.</p>

<h3>Choosing your own schedule</h3>
<p>Pick whatever cadence suits you — the installer accepts the interval and time:</p>

<pre class="term">:: default: every 24 hours at 03:00
venv\\Scripts\\python.exe scripts\\install_task.py

:: every 12 hours at 03:00 and 15:00
venv\\Scripts\\python.exe scripts\\install_task.py --interval-hours 12

:: every 6 hours
venv\\Scripts\\python.exe scripts\\install_task.py --interval-hours 6

:: weekly on Sunday at 03:00
venv\\Scripts\\python.exe scripts\\install_task.py --weekly --day Sunday

:: run at a different time of day
venv\\Scripts\\python.exe scripts\\install_task.py --at 22:30

:: stop the automatic task entirely
venv\\Scripts\\python.exe scripts\\install_task.py --disable

:: see what is currently registered
venv\\Scripts\\python.exe scripts\\install_task.py --show</pre>

<table>
<tr><th style="width:24%">Option</th><th>Effect</th></tr>
<tr><td><code>--interval-hours N</code></td><td>Run every N hours (default 24)</td></tr>
<tr><td><code>--at HH:MM</code></td><td>Time of day for the run (default 03:00)</td></tr>
<tr><td><code>--weekly --day D</code></td><td>Run weekly on day D instead of hourly</td></tr>
<tr><td><code>--disable</code></td><td>Remove the task; re-index manually when you choose</td></tr>
<tr><td><code>--show</code></td><td>Print the current task definition</td></tr>
</table>

<div class="note">
<strong>Leaving it on is the recommended default.</strong> A 24-hour cycle means your
archive is never more than a day stale, and the incremental merge keeps the cost
near zero. If you prefer to control it yourself, <code>--disable</code> removes the
task and you simply run the re-index after each export.
</div>

<h3>Manual re-index</h3>
<pre class="term">C:\\TotalRecalls-Search&gt; venv\\Scripts\\python.exe scripts\\reindex_all.py</pre>

<h3>What gets logged</h3>
<p>Every scheduled run appends to <code>reindex_log.txt</code> in the install folder,
so you can see exactly what happened and when.</p>

<h2>11. Scripts reference</h2>
<p>Every script in the package, with its full source. They are also on disk under
<code>scripts\\</code>.</p>

<h3>Core</h3>
<table>
<tr><th style="width:34%">Script</th><th>What it does</th></tr>
<tr><td><code>build_sql_container.py</code></td><td>Parses every <code>conversation.json</code> into the SQLite container</td></tr>
<tr><td><code>build_vector_index.py</code></td><td>Embeds every <code>conversation.md</code> into the LanceDB index</td></tr>
<tr><td><code>search_my_ai.py</code></td><td>Natural-language search across all providers</td></tr>
<tr><td><code>chat_server.py</code></td><td>Local chat UI + OpenAI-compatible API with retrieval</td></tr>
<tr><td><code>export_for_notion.py</code></td><td>Exports the archive as Notion-ready Markdown (and optional API sync)</td></tr>
</table>

<h3>Operations</h3>
<table>
<tr><th style="width:34%">Script</th><th>What it does</th></tr>
<tr><td><code>reindex_all.py</code></td><td>Re-runs both indexes; used by the scheduled task</td></tr>
<tr><td><code>install_task.py</code></td><td>Sets up, reconfigures or removes the automatic re-index task</td></tr>
<tr><td><code>verify_install.py</code></td><td>Checks the whole installation end to end</td></tr>
<tr><td><code>tr_discovery.py</code></td><td>Shared discovery of conversations in the library</td></tr>
<tr><td><code>test_suite.py</code></td><td>Assertions over the system's behaviour</td></tr>
</table>

<h3>Source</h3>
""")

    # Embed each script
    for name in [
        "build_sql_container.py",
        "build_vector_index.py",
        "search_my_ai.py",
        "chat_server.py",
        "export_for_notion.py",
        "reindex_all.py",
        "install_task.py",
        "tr_discovery.py",
        "verify_install.py",
    ]:
        path = os.path.join(SCRIPTS, name)
        if os.path.isfile(path):
            parts.append(f'<h4>{esc(name)}</h4>\n{code_block(path)}\n')

    parts.append("""
<h2>12. Notes</h2>

<h3>Verified before shipping</h3>
<table>
<tr><th style="width:62%">Check</th><th>Result</th></tr>
<tr><td>All eight providers indexed by both containers</td><td class="ok">PASS</td></tr>
<tr><td>SQLite row count matches the library (415)</td><td class="ok">PASS</td></tr>
<tr><td>Vector chunks trace back to real files on disk</td><td class="ok">PASS</td></tr>
<tr><td>Re-index is idempotent (no duplicate rows)</td><td class="ok">PASS</td></tr>
<tr><td>Incremental merge adds only new conversations</td><td class="ok">PASS</td></tr>
<tr><td>A new provider appears in an existing index</td><td class="ok">PASS</td></tr>
<tr><td>Live search returns real content, not metadata</td><td class="ok">PASS</td></tr>
<tr><td>Chat retrieval spans multiple providers</td><td class="ok">PASS</td></tr>
<tr><td>Scheduled task registers and repeats correctly</td><td class="ok">PASS</td></tr>
<tr><td>Automated test suite (37 assertions)</td><td class="ok">PASS</td></tr>
</table>

<p class="muted">Re-run the checks any time with
<code>scripts\\verify_install.py</code> and <code>scripts\\test_suite.py</code>.</p>

<h3>Storage locations</h3>
<table>
<tr><th style="width:34%">Location</th><th>Contents</th></tr>
<tr><td><code>C:\\TotalRecalls-Downloads\\Library\\</code></td><td>Your exported conversations — the source of truth. Keep it.</td></tr>
<tr><td><code>C:\\TotalRecalls-Search\\data\\</code></td><td>The SQLite container</td></tr>
<tr><td><code>C:\\TotalRecalls-Search\\vector_store\\</code></td><td>The LanceDB vector index</td></tr>
<tr><td><code>C:\\TotalRecalls-Search\\notion_export\\</code></td><td>Generated Notion pages (one file per conversation, after you export)</td></tr>
<tr><td><code>%USERPROFILE%\\.cache\\huggingface\\</code></td><td>The embedding model, downloaded once</td></tr>
</table>

<h3>Disk usage</h3>
<p>Roughly 1.5 GB for the Python environment, plus the embedding model (~400 MB) and
the indexes themselves. The vector index grows with your archive — a few megabytes
per thousand conversations.</p>

<h3>Privacy</h3>
<p>Retrieval reads only local files. Generation is sent to the local model endpoint
on your own machine. Nothing is transmitted to TotalRecalls, to any AI provider, or
to any cloud service.</p>

<h3>Requirements</h3>
<table>
<tr><th style="width:26%">Component</th><th>Requirement</th></tr>
<tr><td>Operating system</td><td>Windows 10 or later</td></tr>
<tr><td>Memory</td><td>8 GB recommended (16 GB comfortable)</td></tr>
<tr><td>Disk</td><td>~2 GB free for the environment and indexes</td></tr>
<tr><td>Python</td><td>3.11 or later (bundled in <code>venv\\</code>)</td></tr>
<tr><td>LM Studio</td><td>Optional — only needed for the chat interface</td></tr>
</table>

<div class="foot">
TotalRecalls Power User Guide · Local Vector Search &amp; SQL Container<br>
Covers all eight providers: ChatGPT, Claude, Perplexity, Gemini, Grok, DeepSeek,
Mistral, Qwen.<br>
Runs entirely on your own machine.
</div>

</body></html>
""")

    return "".join(parts)


def main() -> int:
    out = os.path.join(DOCS, "guide.html")
    html_doc = build_html()
    # Substitute captured live transcripts (kept out of the f-strings so the
    # HTML braces in them are not interpreted as interpolation).
    html_doc = html_doc.replace("@@QUERY_OUTPUT@@", esc(live_query_output()))
    html_doc = html_doc.replace("@@CHAT_TRANSCRIPT@@", esc(live_chat_output()))
    nollm_path = os.path.join(DOCS, "_chat_nollm.txt")
    html_doc = html_doc.replace(
        "@@CHAT_NOLLM@@",
        esc(open(nollm_path, encoding="utf-8").read().strip())
        if os.path.isfile(nollm_path) else "(retrieval-only transcript not captured)")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(html_doc)
    print(f"[OK] wrote {out} ({len(html_doc):,} chars)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
