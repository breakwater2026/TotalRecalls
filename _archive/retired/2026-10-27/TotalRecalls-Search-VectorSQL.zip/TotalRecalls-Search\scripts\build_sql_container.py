#!/usr/bin/env python
"""Rebuild the local SQLite metadata container from the TotalRecalls library.

Discovers every conversation regardless of nesting depth, so adding a provider
requires no code change.

Writes: C:\\TotalRecalls-Search\\data\\totalrecalls_chats.db

Run:  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe build_sql_container.py
"""
from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tr_discovery import (  # noqa: E402
    SUPPORTED_PROVIDERS,
    conversation_body,
    dir_identity,
    display_name,
    find_conversations,
    provider_coverage,
    read_json,
)

DEFAULT_LIBRARY = r"C:\TotalRecalls-Downloads\Library"
DEFAULT_DB = r"C:\TotalRecalls-Search\data\totalrecalls_chats.db"

SCHEMA_VERSION = 3

SCHEMA = """
CREATE TABLE IF NOT EXISTS chats (
    row_pk      INTEGER PRIMARY KEY AUTOINCREMENT,
    conv_key    TEXT NOT NULL UNIQUE,   -- stable key: provider/relative dir path
    provider    TEXT NOT NULL,
    folder      TEXT NOT NULL,
    title       TEXT,
    conv_label  TEXT,                   -- dir name minus exporter artifacts
    occurred_at TEXT,                   -- local wall-clock time from dir name
    created_at  TEXT,                   -- UTC from conversation.json
    updated_at  TEXT,
    message_count INTEGER NOT NULL DEFAULT 0,
    char_count  INTEGER NOT NULL DEFAULT 0,
    json_path   TEXT NOT NULL,
    md_path     TEXT
);

CREATE TABLE IF NOT EXISTS messages (
    message_pk  INTEGER PRIMARY KEY AUTOINCREMENT,
    conv_key    TEXT NOT NULL,
    ordinal     INTEGER NOT NULL,
    role        TEXT NOT NULL,
    model       TEXT,
    created_at  TEXT,
    char_count  INTEGER NOT NULL DEFAULT 0,
    external_id TEXT,
    content_md  TEXT,
    UNIQUE(conv_key, ordinal)
);

CREATE INDEX IF NOT EXISTS idx_chats_provider ON chats(provider);
CREATE INDEX IF NOT EXISTS idx_chats_created  ON chats(created_at);
CREATE INDEX IF NOT EXISTS idx_msgs_conv      ON messages(conv_key, ordinal);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


def main() -> int:
    ap = argparse.ArgumentParser(description="Build the TotalRecalls SQLite container.")
    ap.add_argument("--library", default=DEFAULT_LIBRARY)
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--rebuild", action="store_true", help="delete the existing DB first")
    args = ap.parse_args()

    library = os.path.abspath(args.library)
    db_path = os.path.abspath(args.db)

    if not os.path.isdir(library):
        print(f"[ERROR] library not found: {library}", file=sys.stderr)
        return 2

    if args.rebuild and os.path.exists(db_path):
        os.remove(db_path)
        print(f"[REBUILD] removed existing {db_path}")

    convs = find_conversations(library)
    if not convs:
        print(f"[ERROR] no conversation.json found under {library}", file=sys.stderr)
        return 1

    cov = provider_coverage(convs)

    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.executescript(SCHEMA)

    stats: dict[str, int] = {}
    skipped: list[str] = []
    n_chats = n_msgs = 0

    for c in convs:
        provider = c["provider"]
        data = read_json(c["json_path"])
        if data is None:
            skipped.append(c["rel_dir"])
            continue

        conv = conversation_body(data)
        messages = conv.get("messages") or []
        occurred, _short = dir_identity(c["conv_name"])
        conv_key = f"{provider}/{c['rel_dir']}"

        md_text = ""
        if c["md_path"] and os.path.isfile(c["md_path"]):
            with open(c["md_path"], "r", encoding="utf-8", errors="replace") as fh:
                md_text = fh.read()

        cur.execute(
            """INSERT OR REPLACE INTO chats
               (conv_key, provider, folder, title, conv_label, occurred_at,
                created_at, updated_at, message_count, char_count, json_path, md_path)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                conv_key, provider, c["folder"], conv.get("title"),
                display_name(c["conv_name"]), occurred,
                conv.get("created_at"), conv.get("updated_at"),
                len(messages), len(md_text), c["json_path"], c["md_path"],
            ),
        )

        cur.executemany(
            """INSERT OR REPLACE INTO messages
               (conv_key, ordinal, role, model, created_at, char_count, external_id, content_md)
               VALUES (?,?,?,?,?,?,?,?)""",
            [
                (
                    conv_key, i, m.get("role", "?"), m.get("model", ""),
                    m.get("created_at"), len(m.get("content_md", "")),
                    m.get("external_id"), m.get("content_md", ""),
                )
                for i, m in enumerate(messages)
            ],
        )

        stats[provider] = stats.get(provider, 0) + 1
        n_chats += 1
        n_msgs += len(messages)

    cur.execute(
        "INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)",
        (str(SCHEMA_VERSION),),
    )
    cur.execute(
        "INSERT OR REPLACE INTO meta(key,value) VALUES('built_at',?)",
        (datetime.now(timezone.utc).isoformat(),),
    )
    cur.execute(
        "INSERT OR REPLACE INTO meta(key,value) VALUES('library_root',?)", (library,)
    )
    conn.commit()

    print()
    print("=" * 72)
    print("SQL CONTAINER BUILT")
    print("=" * 72)
    print(f"[DATABASE] {db_path}")
    print(f"[ROOT]     {library}")
    print()
    for provider in sorted(stats):
        print(f"[PARSED]   {stats[provider]:>4} {provider} conversations")
    print("-" * 72)
    print(f"[TOTAL]    {n_chats} conversations, {n_msgs} messages")

    print()
    print(f"[COVERAGE] {len(cov['present'])}/{len(SUPPORTED_PROVIDERS)} providers indexed")
    if cov["missing"]:
        print(f"[PENDING]  not yet exported: {', '.join(cov['missing'])}")
    if cov["unexpected"]:
        print(f"[NOTICE]   unrecognised provider folders: {', '.join(cov['unexpected'])}")

    if skipped:
        print(f"[SKIPPED]  {len(skipped)} unreadable conversation.json")
        for s in skipped[:10]:
            print(f"             - {s}")
    conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
