#!/usr/bin/env python
"""Build the offline LanceDB vector index from TotalRecalls Markdown exports.

Discovers every conversation regardless of nesting depth, so adding a provider
requires no code change.

Reads:  C:\\TotalRecalls-Downloads\\Library\\  (any layout)
Writes: C:\\TotalRecalls-Search\\vector_store\\  (LanceDB table "ai_knowledge_base")

Embeddings are computed 100% locally by sentence-transformers
(all-MiniLM-L6-v2, 384 dims). Nothing leaves the machine.

Chunking: 500-char windows with 50-char overlap (the memo's window, made
non-destructive so sentences are never split mid-thought).

Run:  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe build_vector_index.py
"""
from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tr_discovery import (  # noqa: E402
    SUPPORTED_PROVIDERS,
    display_name,
    find_conversations,
    provider_coverage,
)

DEFAULT_LIBRARY = r"C:\TotalRecalls-Downloads\Library"
DEFAULT_STORE = r"C:\TotalRecalls-Search\vector_store"
DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")


def chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP):
    """Sliding windows. Overlap keeps context across chunk boundaries."""
    if not text.strip():
        return []
    step = size - overlap
    chunks = []
    start = 0
    while start < len(text):
        window = text[start:start + size]
        if window.strip():
            chunks.append((start, window))
        start += step
    return chunks


# TotalRecalls prepends a metadata block of "**Key:** value" bullets after the
# title. These bullets are identical in every file, so embedding them wastes the
# index on boilerplate and pollutes results.
import re  # noqa: E402

META_BULLET_RE = re.compile(r"^- \*\*[^*]+:\*\*.*$", re.MULTILINE)


def strip_metadata_header(md_text: str) -> str:
    """Remove the per-file metadata block, keep the actual conversation.

    TotalRecalls writes a title plus a block of identical "**Key:** value"
    bullets BEFORE the conversation body:

        # Title
        - **Provider:** chatgpt
        - **Account:** chatgpt-session@local
        - **Folder:** Home
        - **ID:** ...
        - **Occurred:** ...
        - **Created:** ...
        - **Updated:** ...
        ---
        ## Q1: the real conversation starts here

    Those bullets are byte-identical across every file, so embedding them
    wastes index space on boilerplate and pushes real content out of the top
    results. The H1 title is kept — it is real, per-conversation context.
    """
    lines = md_text.split("\n")
    out: list[str] = []
    in_fm = False          # inside a YAML-ish --- front matter block
    in_header = True       # still before the metadata terminator
    saw_bullets = False

    for i, line in enumerate(lines):
        s = line.strip()

        if i == 0 and s == "---":
            in_fm = True
            continue
        if in_fm:
            if s == "---":
                in_fm = False
            continue

        if in_header:
            if s == "---":
                # End of the metadata block: everything after this is body.
                in_header = False
                continue
            if META_BULLET_RE.match(line):
                saw_bullets = True
                continue
            # The H1 title is real context — keep it.
            out.append(line)
            continue

        out.append(line)

    body = "\n".join(out).strip()
    # Fall back to the raw text only if the format was never recognised.
    if not body or (not saw_bullets and not in_fm and "---" not in md_text):
        return md_text
    return body


def list_tables(db) -> list[str]:
    """lancedb renamed table_names() -> list_tables() in 0.40, and the new call
    returns a ListTablesResponse rather than a list. Normalize both."""
    try:
        resp = db.list_tables()
    except (AttributeError, TypeError):
        return list(db.table_names())
    if hasattr(resp, "tables"):
        return list(resp.tables)
    return list(resp)


def main() -> int:
    ap = argparse.ArgumentParser(description="Build the local LanceDB vector index.")
    ap.add_argument("--library", default=DEFAULT_LIBRARY)
    ap.add_argument("--store", default=DEFAULT_STORE)
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--chunk-size", type=int, default=CHUNK_SIZE)
    ap.add_argument("--overlap", type=int, default=CHUNK_OVERLAP)
    ap.add_argument("--limit-files", type=int, default=0,
                    help="index only the first N conversation files (smoke test)")
    ap.add_argument("--overwrite", action="store_true",
                    help="replace the existing table instead of merging")
    args = ap.parse_args()

    try:
        import lancedb
        import pandas as pd
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        print(f"[ERROR] missing dependency: {exc}\n"
              f"        run: venv\\Scripts\\python.exe -m pip install -r requirements.txt",
              file=sys.stderr)
        return 2

    library = os.path.abspath(args.library)
    store = os.path.abspath(args.store)
    if not os.path.isdir(library):
        print(f"[ERROR] library not found: {library}", file=sys.stderr)
        return 2

    convs = find_conversations(library)
    if not convs:
        print(f"[ERROR] no conversation.json found under {library}", file=sys.stderr)
        return 1
    if args.limit_files:
        convs = convs[: args.limit_files]

    cov = provider_coverage(convs)

    print(f"[MODEL]   loading {args.model} (100% local, CPU)")
    embedder = SentenceTransformer(args.model, device="cpu")
    dim = embedder.get_embedding_dimension()
    print(f"[MODEL]   {dim} dimensions")
    print(f"[DISCOVERY] {len(convs)} conversations across "
          f"{len(cov['present'])} providers")

    db = lancedb.connect(store)

    rows = []
    files_indexed = 0
    skipped = 0

    for c in convs:
        path = c["md_path"]
        if not path or not os.path.isfile(path):
            skipped += 1
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                raw = fh.read()
        except OSError as exc:
            print(f"  [WARN] {path}: {exc}", file=sys.stderr)
            skipped += 1
            continue

        text = strip_metadata_header(raw)
        chunks = chunk_text(text, args.chunk_size, args.overlap)
        if not chunks:
            skipped += 1
            continue

        # Batch-embed per file: much faster than per-chunk calls.
        vectors = embedder.encode(
            [ch[1] for ch in chunks],
            batch_size=64,
            show_progress_bar=False,
            convert_to_numpy=True,
        )

        rel = os.path.relpath(path, library).replace("\\", "/")
        for (offset, chunk), vec in zip(chunks, vectors):
            rows.append({
                "chunk_id": f"{rel}::{offset}",
                "vector": vec.tolist(),
                "text": chunk,
                "provider": c["provider"],
                "conversation": display_name(c["conv_name"]),
                "path": path.replace("\\", "/"),
                "char_offset": offset,
                "chunk_size": args.chunk_size,
                "indexed_at": datetime.now(timezone.utc).isoformat(),
            })

        files_indexed += 1
        if files_indexed % 25 == 0:
            print(f"[INDEX]   {files_indexed}/{len(convs)} files, {len(rows)} chunks")

    if not rows:
        print("[ERROR] no chunks produced", file=sys.stderr)
        return 1

    df = pd.DataFrame(rows)
    table_name = "ai_knowledge_base"
    print(f"[VECTOR]  {len(df)} chunks x {dim} dims -> LanceDB '{table_name}'")

    if table_name in list_tables(db) and args.overwrite:
        db.drop_table(table_name)
        print(f"[VECTOR]  dropped existing table (overwrite)")

    if table_name in list_tables(db):
        table = db.open_table(table_name)
        # Add only chunk_ids not already present (idempotent re-index).
        existing = {r["chunk_id"] for r in table.search().limit(None).to_list()}
        new_df = df[~df["chunk_id"].isin(existing)]
        if len(new_df):
            table.add(new_df)
            print(f"[VECTOR]  merged {len(new_df)} new chunks "
                  f"({len(existing)} already present)")
        else:
            print("[VECTOR]  nothing new to add (index already current)")
    else:
        table = db.create_table(table_name, data=df, mode="overwrite")
        print(f"[VECTOR]  created table with {len(df)} chunks")

    print()
    print("=" * 72)
    print("VECTOR INDEX BUILT")
    print("=" * 72)
    print(f"[STORE]    {os.path.join(store, table_name + '.lance')}")
    print(f"[MODEL]    {args.model}")
    print(f"[FILES]    {files_indexed} conversations indexed ({skipped} skipped)")
    print(f"[CHUNKS]   {len(df)} total ({args.chunk_size} chars, {args.overlap} overlap)")
    print(f"[DIMS]     {dim}")
    print()
    print(f"[COVERAGE] {len(cov['present'])}/{len(SUPPORTED_PROVIDERS)} providers indexed")
    if cov["missing"]:
        print(f"[PENDING]  not yet exported: {', '.join(cov['missing'])}")
    if cov["unexpected"]:
        print(f"[NOTICE]   unrecognised provider folders: {', '.join(cov['unexpected'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
