#!/usr/bin/env python
"""Local RAG chat server for the TotalRecalls search system.

Serves a web chat UI and an OpenAI-compatible API on http://localhost:8000.

Each user message is embedded and used to retrieve the most relevant chunks from
the LanceDB vector index; those chunks are prepended as context and the prompt
is sent to a local LLM for generation.

Generation backend (in order of preference):
  1. LM Studio's local server   (http://localhost:1234/v1)  — default
  2. Any other OpenAI-compatible endpoint via --llm-base-url

Nothing is sent to the cloud: retrieval is local, and generation goes to the
local model you already run.

Run:
  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe chat_server.py
  then open http://localhost:8000
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

DEFAULT_STORE = r"C:\TotalRecalls-Search\vector_store"
DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
TABLE = "ai_knowledge_base"
DEFAULT_LLM_URL = "http://localhost:1234/v1"
DEFAULT_LLM_MODEL = "qwen3-30b-a3b-instruct-2507"
PORT = 8000

SYSTEM_PROMPT = (
    "You are a research assistant with access to the user's own archive of AI "
    "conversations across eight providers (ChatGPT, Claude, Perplexity, Gemini, "
    "Grok, DeepSeek, Mistral, Qwen).\n\n"
    "Answer using ONLY the retrieved conversation excerpts provided below. "
    "Quote or paraphrase from them. If the excerpts do not contain the answer, "
    "say so plainly rather than inventing anything. When you use an excerpt, "
    "name which provider it came from.\n\n"
    "RETRIEVED EXCERPTS:\n"
)


def retrieve(query: str, store: str, model_name: str, k: int = 6) -> list[dict]:
    """Return the top-k most relevant chunks for a query."""
    import lancedb
    from sentence_transformers import SentenceTransformer

    db = lancedb.connect(store)
    try:
        resp = db.list_tables()
        tables = list(resp.tables) if hasattr(resp, "tables") else list(resp)
    except (AttributeError, TypeError):
        tables = list(db.table_names())
    if TABLE not in tables:
        return []

    table = db.open_table(TABLE)
    embedder = SentenceTransformer(model_name, device="cpu")
    vec = embedder.encode(query, convert_to_numpy=True).tolist()
    rows = table.search(vec).limit(k).to_list()
    for i, r in enumerate(rows):
        dist = r.get("_distance")
        r["score"] = round(1.0 - (dist / 2.0), 4) if dist is not None else 0.0
    return rows


def build_context(chunks: list[dict]) -> str:
    parts = []
    for i, c in enumerate(chunks, 1):
        text = " ".join(c["text"].split())
        parts.append(
            f"[{i}] provider={c['provider']}  file={c['path']}\n{text}"
        )
    return "\n\n".join(parts)


def llm_chat(messages: list[dict], base_url: str, model: str,
             temperature: float = 0.3, max_tokens: int = 700) -> str:
    """Call an OpenAI-compatible chat endpoint."""
    payload = json.dumps({
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }).encode("utf-8")
    req = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=300) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"]


def detect_llm(base_url: str) -> str | None:
    """Return the first available model id at the endpoint, or None."""
    try:
        req = urllib.request.Request(base_url.rstrip("/") + "/models")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        ids = [m.get("id") for m in data.get("data", [])]
        return ids[0] if ids else None
    except Exception:
        return None


HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>TotalRecalls — Local Chat</title>
<style>
  body{margin:0;font-family:"Segoe UI",Arial,sans-serif;background:#f6f7f9;color:#1a1a1a}
  .wrap{max-width:900px;margin:0 auto;padding:22px 18px}
  h1{font-size:19px;margin:0 0 4px;color:#0b2545}
  .sub{font-size:12px;color:#555;margin-bottom:14px}
  #log{border:1px solid #d8dde3;border-radius:8px;background:#fff;padding:16px;
       height:52vh;overflow-y:auto;font-size:13.5px;line-height:1.55}
  .msg{margin:0 0 14px;padding:11px 14px;border-radius:8px;white-space:pre-wrap}
  .user{background:#e8f0fe}
  .bot{background:#f1f3f5}
  .ctx{background:#fff8e6;font-size:12px;color:#5a4b00;max-height:190px;overflow-y:auto}
  .ctx b{color:#7a6500}
  form{display:flex;gap:8px;margin-top:14px}
  input{flex:1;padding:11px;border:1px solid #c3c9d1;border-radius:6px;font-size:14px}
  button{padding:11px 20px;background:#0b2545;color:#ffffff;border:0;border-radius:6px;
         font-size:14px;cursor:pointer}
  .meta{font-size:11.5px;color:#777;margin-top:10px}
</style></head><body><div class="wrap">
<h1>TotalRecalls — Local Chat</h1>
<div class="sub">Retrieval: local LanceDB &nbsp;·&nbsp; Generation: local LM Studio model &nbsp;·&nbsp; No cloud</div>
<div id="log"></div>
<form id="f"><input id="q" placeholder="Ask across all 8 providers…" autocomplete="off"><button>Send</button></form>
<div class="meta" id="meta"></div>
<script>
const log=document.getElementById('log'), q=document.getElementById('q');
function add(cls,html){const d=document.createElement('div');d.className='msg '+cls;
  d.innerHTML=html;log.appendChild(d);log.scrollTop=log.scrollHeight;return d;}
document.getElementById('f').onsubmit=async e=>{
  e.preventDefault(); const text=q.value.trim(); if(!text) return;
  q.value=''; add('user',text.replace(/</g,'&lt;'));
  const b=add('bot','<i>Retrieving…</i>');
  try{
    const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({message:text})});
    const j=await r.json();
    if(j.error){b.innerHTML='<b>Error:</b> '+j.error;return;}
    let h=j.answer;
    b.innerHTML=h;
    const c=document.createElement('div');c.className='msg ctx';
    c.innerHTML='<b>Retrieved context ('+j.chunks.length+' chunks)</b><br>'+
      j.chunks.map(x=>'['+x.provider+'] '+x.path.split('/').pop()+' <i>('+x.score+')</i>').join('<br>');
    log.appendChild(c); log.scrollTop=log.scrollHeight;
    document.getElementById('meta').textContent=
      'model: '+j.model+'   ·   llm: '+j.llm+'   ·   '+j.chunks.length+' chunks retrieved';
  }catch(err){b.innerHTML='<b>Request failed:</b> '+err;}
};
</script></body></html>"""


def main() -> int:
    ap = argparse.ArgumentParser(description="Local RAG chat server")
    ap.add_argument("--store", default=DEFAULT_STORE)
    ap.add_argument("--model", default=DEFAULT_MODEL, help="embedding model")
    ap.add_argument("--llm-base-url", default=DEFAULT_LLM_URL)
    ap.add_argument("--llm-model", default=DEFAULT_LLM_MODEL)
    ap.add_argument("--top-k", type=int, default=6)
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--no-llm", action="store_true",
                    help="retrieval-only chat: show the matching excerpts without "
                         "calling a language model. Use this when no local model "
                         "can run on this machine.")
    args = ap.parse_args()

    if not os.path.isdir(args.store):
        print(f"[ERROR] vector store not found: {args.store}", file=sys.stderr)
        return 2

    if args.no_llm:
        llm_model = None
        print("[MODE]   retrieval only — no language model required")
    else:
        detected = detect_llm(args.llm_base_url)
        if detected:
            llm_model = detected
        else:
            llm_model = args.llm_model
            print(f"[WARN]    no model found at {args.llm_base_url}; will try "
                  f"'{llm_model}' and may fail. Use --no-llm for retrieval only.")
        print(f"[LLM]    {args.llm_base_url}  ->  {llm_model}")
    print(f"[RETR]   {args.store}")
    print(f"[WEB]    http://localhost:{args.port}")
    print("        (Ctrl+C to stop)")

    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):  # silence per-request logging
            pass

        def _send(self, code: int, body: bytes, ctype: str):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                self._send(200, HTML.encode("utf-8"), "text/html; charset=utf-8")
            elif self.path == "/api/health":
                self._send(200, json.dumps(
                    {"ok": True, "llm": llm_model or "none (retrieval only)"}
                ).encode(), "application/json")
            else:
                self._send(404, b"not found", "text/plain")

        def do_POST(self):
            if self.path not in ("/api/chat", "/v1/chat/completions"):
                self._send(404, b"not found", "text/plain")
                return
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n).decode("utf-8"))
                query = req.get("message") or (req.get("messages") or [{}])[-1].get("content", "")
                if not query:
                    self._send(400, json.dumps({"error": "empty message"}).encode(), "application/json")
                    return

                chunks = retrieve(query, args.store, args.model, args.top_k)

                if args.no_llm:
                    # Retrieval-only answer: present the excerpts themselves,
                    # labelled, with no generation step.
                    if not chunks:
                        answer = "No matching passages were found in your archive."
                    else:
                        parts = ["No language model is attached, so here are the "
                                 "matching passages themselves.\n"]
                        for i, c in enumerate(chunks, 1):
                            text = " ".join(c["text"].split())
                            parts.append(
                                f"--- [{i}] {c['provider']}  "
                                f"similarity {c['score']:.3f}  {c['path']}\n{text}"
                            )
                        answer = "\n\n".join(parts)
                    out = {
                        "answer": answer.replace("<", "&lt;").replace(">", "&gt;"),
                        "chunks": [
                            {"provider": c["provider"], "path": c["path"], "score": c["score"]}
                            for c in chunks
                        ],
                        "model": "none (retrieval only)",
                        "llm": None,
                    }
                    self._send(200, json.dumps(out).encode(), "application/json")
                    return

                context = build_context(chunks)
                messages = [
                    {"role": "system", "content": SYSTEM_PROMPT + context},
                    {"role": "user", "content": query},
                ]
                answer = llm_chat(messages, args.llm_base_url, llm_model)
                out = {
                    "answer": answer.replace("<", "&lt;").replace(">", "&gt;"),
                    "chunks": [
                        {"provider": c["provider"], "path": c["path"], "score": c["score"]}
                        for c in chunks
                    ],
                    "model": llm_model,
                    "llm": args.llm_base_url,
                }
                self._send(200, json.dumps(out).encode(), "application/json")
            except urllib.error.URLError as exc:
                self._send(502, json.dumps(
                    {"error": f"LLM endpoint unreachable: {exc}"}).encode(), "application/json")
            except Exception as exc:  # noqa: BLE001
                self._send(500, json.dumps({"error": repr(exc)}).encode(), "application/json")

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[STOP] server stopped")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
