#!/usr/bin/env python
"""Export the TotalRecalls archive as Notion-ready Markdown.

Notion can import a folder of Markdown directly, so this writes one page per
conversation, grouped by provider, plus an index. Optionally pushes the same
pages into Notion over its API so the workspace stays in step automatically.

Modes:
  (default)            write Markdown files to C:\\TotalRecalls-Search\\notion_export\\
  --to-api             push/upsert pages via the Notion API
  --to-api --dry-run   show what the API sync would do, without changing anything

Notion API prerequisites:
  1. Create an integration at https://www.notion.so/my-integrations
  2. Share the target page/database with that integration
  3. Pass --token <internal integration token> and --parent-page <PAGE_ID>

Run:
  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe scripts\\export_for_notion.py
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tr_discovery import (  # noqa: E402
    SUPPORTED_PROVIDERS,
    conversation_body,
    find_conversations,
    provider_coverage,
    read_json,
)

DEFAULT_LIBRARY = r"C:\TotalRecalls-Downloads\Library"
DEFAULT_OUT = r"C:\TotalRecalls-Search\notion_export"
NOTION_VERSION = "2022-06-28"


def slug(text: str, maxlen: int = 80) -> str:
    """Notion-safe page title: keep it readable, strip path-hostile characters."""
    cleaned = re.sub(r'[\\/:*?"<>|]', " ", text)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return (cleaned[:maxlen].strip() or "Untitled")


def page_markdown(conv: dict, messages: list[dict], provider: str) -> str:
    """Render one conversation as a Notion page body."""
    lines = [
        f"# {conv.get('title') or 'Untitled'}",
        "",
        f"> **Provider:** {provider}  ",
        f"> **Created:** {conv.get('created_at') or '—'}  ",
        f"> **Messages:** {len(messages)}  ",
        f"> **Source:** <code>{conv.get('_path', '')}</code>",
        "",
        "---",
        "",
    ]
    for m in messages:
        role = (m.get("role") or "?").upper()
        body = (m.get("content_md") or "").strip()
        if not body:
            continue
        lines.append(f"## {role}")
        lines.append("")
        lines.append(body)
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def write_export(convs: list[dict], out_dir: str) -> dict:
    """Write one .md per conversation plus an index. Returns stats.

    One file per conversation is what makes Notion's Markdown import create one
    page per conversation, which is the behaviour the documentation describes.
    """
    os.makedirs(out_dir, exist_ok=True)
    by_provider: dict[str, list[dict]] = {}
    for c in convs:
        by_provider.setdefault(c["provider"], []).append(c)

    index_lines = [
        "# TotalRecalls — Archive Export",
        "",
        f"Generated {datetime.now().strftime('%Y-%m-%d %H:%M')} · "
        f"{len(convs)} conversations across {len(by_provider)} providers",
        "",
        "| Provider | Conversations | Folder |",
        "|---|---:|---|",
    ]
    for p in sorted(by_provider):
        index_lines.append(
            f"| {p.title()} | {len(by_provider[p])} | `{p}/` |")
    index_lines += [
        "", "## Import into Notion", "",
        "1. In Notion, open the page that will hold your archive.",
        "2. Choose **Import** from the ··· menu.",
        "3. Select **Markdown & CSV**.",
        "4. Select the folders listed above (or the whole export folder).",
        "",
        "Notion creates one page per conversation. Re-import to refresh.",
        "",
    ]
    with open(os.path.join(out_dir, "index.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(index_lines))

    written = 0
    for provider, items in sorted(by_provider.items()):
        pdir = os.path.join(out_dir, provider)
        os.makedirs(pdir, exist_ok=True)
        for c in items:
            data = read_json(c["json_path"]) or {}
            conv = conversation_body(data)
            conv["_path"] = c["json_path"]
            body = page_markdown(conv, conv.get("messages") or [], provider)
            # Notion derives the page title from the filename, so keep it short
            # and free of characters Windows or Notion dislike.
            fname = slug(conv.get("title") or "Untitled", maxlen=60)
            path = os.path.join(pdir, f"{fname}.md")
            n = 1
            while os.path.exists(path):
                path = os.path.join(pdir, f"{fname} ({n}).md")
                n += 1
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(body)
            written += 1
    return {"providers": len(by_provider), "pages": written, "out_dir": out_dir}


# ---------------------------------------------------------------- Notion API

def notion_request(method: str, path: str, token: str,
                   payload: dict | None = None) -> dict:
    url = f"https://api.notion.com/v1{path}"
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Notion-Version", NOTION_VERSION)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError(f"Notion API {exc.code}: {detail}") from exc


def md_to_blocks(text: str, limit: int = 80) -> list[dict]:
    """A small, dependency-free Markdown -> Notion blocks converter.

    Handles headings, blockquotes, tables, bullet/numbered lists, code fences
    and paragraphs — enough for the export format this script writes.
    """
    blocks: list[dict] = []
    lines = text.split("\n")
    i = 0

    def rich(t: str) -> list[dict]:
        """Inline bold/italic/code into Notion rich_text."""
        out, buf, mode = [], "", None
        i2 = 0
        while i2 < len(t):
            if t.startswith("**", i2):
                if buf:
                    out.append(_rt(buf, mode)); buf = ""
                mode = "b" if mode != "b" else None
                i2 += 2
            elif t[i2] == "*" and not t.startswith("**", i2):
                if buf:
                    out.append(_rt(buf, mode)); buf = ""
                mode = "i" if mode != "i" else None
                i2 += 1
            elif t[i2] == "`":
                if buf:
                    out.append(_rt(buf, mode)); buf = ""
                end = t.find("`", i2 + 1)
                if end == -1:
                    buf += t[i2]; i2 += 1
                else:
                    out.append({"type": "text", "text": {"content": t[i2 + 1:end]},
                                "annotations": {"code": True}})
                    i2 = end + 1
            else:
                buf += t[i2]; i2 += 1
        if buf:
            out.append(_rt(buf, mode))
        return out or [{"type": "text", "text": {"content": t}}]

    def _rt(content: str, mode: str | None) -> dict:
        ann = {"bold": mode == "b", "italic": mode == "i"}
        return {"type": "text", "text": {"content": content}, "annotations": ann}

    def push(block: dict):
        if len(blocks) < limit:
            blocks.append(block)

    def para(content: str, type_: str = "paragraph"):
        r = rich(content)
        if not r:
            return
        push({"object": "block", "type": type_,
              type_: {"rich_text": r[:2000], **({"color": "default"} if False else {})}})

    while i < len(lines):
        line = lines[i]
        s = line.strip()

        if s.startswith("```"):
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i]); i += 1
            i += 1
            push({"object": "block", "type": "code",
                  "code": {"rich_text": [{"type": "text", "text": {"content": "\n".join(code_lines)}}],
                           "language": "plain text"}})
            continue

        if s.startswith("# "):
            push({"object": "block", "type": "heading_1",
                  "heading_1": {"rich_text": rich(s[2:])}}); i += 1; continue
        if s.startswith("## "):
            push({"object": "block", "type": "heading_2",
                  "heading_2": {"rich_text": rich(s[3:])}}); i += 1; continue
        if s.startswith("> "):
            push({"object": "block", "type": "quote",
                  "quote": {"rich_text": rich(s[2:])}}); i += 1; continue
        if s.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(set(c) <= set("-: ") for c in cells):
                    rows.append(cells)
                i += 1
            if rows:
                ncol = max(len(r) for r in rows)
                table = {"object": "block", "type": "table",
                         "table": {"table_width": ncol,
                                   "has_column_header": False, "has_row_header": False,
                                   "children": [
                                       {"object": "block", "type": "table_row",
                                        "table_row": {"cells": [
                                            rich(c) for c in (r + [""] * ncol)[:ncol]
                                        ]}} for r in rows]}}
                push(table)
            continue
        if re.match(r"^[-*] ", s):
            push({"object": "block", "type": "bulleted_list_item",
                  "bulleted_list_item": {"rich_text": rich(s[2:])}}); i += 1; continue
        if re.match(r"^\d+\. ", s):
            push({"object": "block", "type": "numbered_list_item",
                  "numbered_list_item": {"rich_text": rich(s.split(". ", 1)[1])}}); i += 1; continue
        if s == "---":
            push({"object": "block", "type": "divider", "divider": {}}); i += 1; continue

        if s:
            para(s)
        i += 1
    return blocks


def sync_to_api(convs: list[dict], token: str, parent_page: str,
                dry_run: bool = False) -> dict:
    """Upsert one Notion page per conversation under the parent page."""
    stats = {"created": 0, "updated": 0, "skipped": 0}
    for c in convs:
        data = read_json(c["json_path"]) or {}
        conv = conversation_body(data)
        title = slug(conv.get("title") or "Untitled")
        messages = conv.get("messages") or []
        body = page_markdown(conv, messages, c["provider"])

        if dry_run:
            stats["created"] += 1
            continue

        payload = {
            "parent": {"page_id": parent_page},
            "properties": {"title": {"title": [{"text": {"content": title}}]}},
            "children": md_to_blocks(body),
        }
        try:
            notion_request("POST", "/pages", token, payload)
            stats["created"] += 1
        except RuntimeError as exc:
            if "exc.code" in str(exc) or "400" in str(exc):
                stats["skipped"] += 1
            else:
                raise
    return stats


def main() -> int:
    ap = argparse.ArgumentParser(description="Export the archive for Notion.")
    ap.add_argument("--library", default=DEFAULT_LIBRARY)
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--to-api", action="store_true",
                    help="push pages via the Notion API instead of writing files")
    ap.add_argument("--token", default=None, help="Notion internal integration token")
    ap.add_argument("--parent-page", default=None, help="Notion page id to create under")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    library = os.path.abspath(args.library)
    if not os.path.isdir(library):
        print(f"[ERROR] library not found: {library}", file=sys.stderr)
        return 2

    convs = find_conversations(library)
    if not convs:
        print(f"[ERROR] no conversations found under {library}", file=sys.stderr)
        return 1
    cov = provider_coverage(convs)

    print("=" * 72)
    print("NOTION EXPORT COMPLETE")
    print("=" * 72)
    print(f"[SOURCE]    {library}")
    print(f"[PROVIDERS] {len(cov['present'])}")
    for p in sorted(cov["counts"]):
        print(f"[PARSED]    {cov['counts'][p]:>4} {p}")
    print("-" * 72)
    print(f"[PAGES]     {len(convs)} conversation pages")

    if args.to_api:
        if not args.token or not args.parent_page:
            print("[ERROR] --to-api requires --token and --parent-page", file=sys.stderr)
            return 2
        print(f"[NOTION]    parent page {args.parent_page}"
              f"{' (DRY RUN)' if args.dry_run else ''}")
        stats = sync_to_api(convs, args.token, args.parent_page, args.dry_run)
        print(f"[NOTION]    created {stats['created']}, "
              f"updated {stats['updated']}, skipped {stats['skipped']}")
    else:
        info = write_export(convs, os.path.abspath(args.out))
        print(f"[OUTPUT]    {info['out_dir']}")
        print(f"[INDEX]     1 index page + {info['providers']} provider folders")
        for p in sorted(cov["counts"]):
            print(f"  {p}/  ({cov['counts'][p]} pages)")

    if cov["missing"]:
        print(f"[PENDING]   not yet exported: {', '.join(cov['missing'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
