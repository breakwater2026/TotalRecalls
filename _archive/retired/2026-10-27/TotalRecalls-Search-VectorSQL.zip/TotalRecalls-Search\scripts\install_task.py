#!/usr/bin/env python
"""Install, reconfigure, or remove the automatic re-index scheduled task.

You choose how often the system maintains itself. Defaults to once every 24
hours at 03:00.

Options:
  --interval-hours N   run every N hours            (default 24)
  --at HH:MM           time of day for the run      (default 03:00)
  --weekly --day D     run weekly on day D instead  (e.g. Sunday)
  --disable            remove the task entirely
  --show               print the current task definition

Run:
  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe scripts\\install_task.py
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VENV_PY = os.path.join(ROOT, "venv", "Scripts", "python.exe")
SCRIPT = os.path.join(ROOT, "scripts", "reindex_all.py")
TASK_NAME = "TotalRecalls-ReIndex"
PS = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                  "System32", "WindowsPowerShell", "v1.0", "powershell.exe")


def ps(script: str) -> tuple[int, str, str]:
    """Run PowerShell with a script block, bypassing execution policy."""
    cmd = [PS, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr


def action_lines() -> str:
    py = VENV_PY.replace('"', '`"')
    sc = SCRIPT.replace('"', '`"')
    return (
        f'$Action  = New-ScheduledTaskAction -Execute "{py}" '
        f'-Argument \'"{sc}"\' -WorkingDirectory "{ROOT}"\n'
    )


def show_task() -> None:
    rc, out, err = ps(
        f'$t = Get-ScheduledTask -TaskName "{TASK_NAME}" -ErrorAction SilentlyContinue; '
        f'if ($t) {{ $t.Triggers | Format-List StartBoundary, DaysOfWeek, WeeksInterval; '
        f'$t.Actions | Format-List Execute, Arguments; "State: " + $t.State }} '
        f'else {{ "No task named {TASK_NAME} is registered." }}'
    )
    print(out.strip() or err.strip())


def remove_task() -> bool:
    rc, out, err = ps(
        f'if (Get-ScheduledTask -TaskName "{TASK_NAME}" -ErrorAction SilentlyContinue) {{ '
        f'Unregister-ScheduledTask -TaskName "{TASK_NAME}" -Confirm:$false; '
        f'"[OK] task removed" }} else {{ "[INFO] no such task" }}'
    )
    print((out or err).strip())
    return rc == 0


def install(interval_hours: int, at: str, weekly: bool, day: str) -> bool:
    if not os.path.isfile(VENV_PY):
        print(f"[ERROR] venv python missing: {VENV_PY}", file=sys.stderr)
        return False
    if not os.path.isfile(SCRIPT):
        print(f"[ERROR] reindex script missing: {SCRIPT}", file=sys.stderr)
        return False

    settings = (
        '$Settings = New-ScheduledTaskSettingsSet -StartWhenAvailable '
        '-ExecutionTimeLimit (New-TimeSpan -Minutes 120) -MultipleInstances IgnoreNew'
    )

    if weekly:
        # Anchor to the next real occurrence of the chosen day so the first run
        # is not silently deferred by a full week.
        trig = (
            f'$now = Get-Date; $d = (7 - [int]$now.DayOfWeek) % 7; '
            f'if ($d -eq 0) {{ $d = 7 }}; '
            f'$Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek {day} '
            f'-WeeksInterval 1 -At $now.Date.AddDays($d).AddHours(3)'
        )
        desc = f"weekly on {day} at 03:00"
    else:
        hh, mm = (at or "03:00").split(":")
        # -RepetitionInterval/-RepetitionDuration are parameters of
        # New-ScheduledTaskTrigger itself; there is no separate cmdlet for them.
        # NOTE: [TimeSpan]::MaxValue serializes to P99999999DT23H59M59S, which
        # Task Scheduler rejects as out of range — use a bounded duration.
        trig = (
            f'$now = Get-Date; '
            f'$Trigger = New-ScheduledTaskTrigger -Once '
            f'-At $now.Date.AddHours({int(hh)}).AddMinutes({int(mm)}) '
            f'-RepetitionInterval (New-TimeSpan -Hours {interval_hours}) '
            f'-RepetitionDuration (New-TimeSpan -Days 3650)'
        )
        desc = f"every {interval_hours} hours at {at}"

    body = "\n".join([
        action_lines().rstrip(),
        trig,
        settings,
        # Unregister any existing task first, otherwise Register-ScheduledTask
        # fails with "ResourceExists".
        f'if (Get-ScheduledTask -TaskName "{TASK_NAME}" -ErrorAction SilentlyContinue) {{ '
        f'Unregister-ScheduledTask -TaskName "{TASK_NAME}" -Confirm:$false }}; '
        f'Register-ScheduledTask -TaskName "{TASK_NAME}" -Action $Action '
        f'-Trigger $Trigger -Settings $Settings '
        f'-Description "Automatic re-index of the TotalRecalls SQL + vector containers" | Out-Null; '
        f'"[OK] task \'{TASK_NAME}\' registered ({desc})"',
    ])
    rc, out, err = ps(body)
    print((out or "").strip())
    if rc != 0 or err.strip():
        print((err or "").strip(), file=sys.stderr)
        return False

    # Report back what was actually registered.
    rc2, out2, _ = ps(
        f'$t = Get-ScheduledTask -TaskName "{TASK_NAME}" -ErrorAction Stop; '
        f'"State  : " + $t.State; '
        f'"Start  : " + $t.Triggers.StartBoundary; '
        f'"Repeat : " + $t.Triggers.Repetition.Interval'
    )
    print((out2 or "").strip())
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description="Configure the re-index task.")
    ap.add_argument("--interval-hours", type=int, default=24)
    ap.add_argument("--at", default="03:00", help="time of day, HH:MM")
    ap.add_argument("--weekly", action="store_true")
    ap.add_argument("--day", default="Sunday")
    ap.add_argument("--disable", action="store_true")
    ap.add_argument("--show", action="store_true")
    args = ap.parse_args()

    if args.show:
        show_task()
        return 0
    if args.disable:
        return 0 if remove_task() else 1
    return 0 if install(args.interval_hours, args.at, args.weekly, args.day) else 1


if __name__ == "__main__":
    raise SystemExit(main())
