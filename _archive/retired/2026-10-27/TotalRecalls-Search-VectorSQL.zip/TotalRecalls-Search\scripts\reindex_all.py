#!/usr/bin/env python
"""Re-run both local indexes (SQLite metadata + LanceDB vectors).

Intended for the Windows scheduled task. Safe to run repeatedly: the SQL
builder upserts, and the vector builder merges only unseen chunk_ids.

Exit code 0 = both indexes current. Non-zero = something needs attention
(the scheduled task logs this to reindex_log.txt).

Run:  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe reindex_all.py
"""
from __future__ import annotations

import os
import subprocess
import sys
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VENV_PY = os.path.join(ROOT, "venv", "Scripts", "python.exe")
LOG = os.path.join(ROOT, "reindex_log.txt")


def log(msg: str) -> None:
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {msg}"
    print(line)
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def run(step: str, script: str) -> bool:
    log(f"{step}: start")
    proc = subprocess.run(
        [VENV_PY, os.path.join(ROOT, "scripts", script)],
        capture_output=True, text=True, cwd=ROOT,
    )
    tail = (proc.stdout or "")[-600:].strip()
    if tail:
        for ln in tail.splitlines():
            log(f"  {ln}")
    if proc.returncode != 0:
        err = (proc.stderr or "").strip()[-600:]
        log(f"{step}: FAILED rc={proc.returncode} {err}")
        return False
    log(f"{step}: ok")
    return True


def main() -> int:
    if not os.path.isfile(VENV_PY):
        log(f"FATAL: venv python missing at {VENV_PY}")
        return 2

    ok_sql = run("SQL", "build_sql_container.py")
    ok_vec = run("VECTOR", "build_vector_index.py")

    if ok_sql and ok_vec:
        log("RESULT: both indexes current")
        return 0
    log("RESULT: one or more index steps failed")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
