#!/usr/bin/env python
"""Cross-provider semantic search over the local TotalRecalls vector index.

Natural-language queries run against every indexed conversation, regardless
of which AI provider originated it. Uses the same local embedding model as
build_vector_index.py, so results are consistent with the index.

Usage:
  python search_my_ai.py "asynchronous queue worker error handling"
  python search_my_ai.py "sierra chart reversal alert" --limit 5 --provider perplexity
  python search_my_ai.py "prop firm rules" --sql          # also show SQL metadata hits

Run:  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe search_my_ai.py "your query"
"""
from __future__ import annotations

import argparse
import os
import sqlite3
import sys

DEFAULT_STORE = r"C:\TotalRecalls-Search\vector_store"
DEFAULT_DB = r"C:\TotalRecalls-Search\data\totalrecalls_chats.db"
DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
TABLE = "ai_knowledge_base"

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tr_discovery import SUPPORTED_PROVIDERS  # noqa: E402


def list_tables(db) -> list[str]:
    """lancedb 0.40 renamed table_names() -> list_tables() and the new call
    returns a ListTablesResponse object, not a list."""
    try:
        resp = db.list_tables()
    except (AttributeError, TypeError):
        return list(db.table_names())
    if hasattr(resp, "tables"):
        return list(resp.tables)
    return list(resp)


def vector_search(query: str, store: str, model_name: str, limit: int,
                  provider: str | None, min_score: float | None) -> int:
    try:
        import lancedb
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        print(f"[ERROR] missing dependency: {exc}", file=sys.stderr)
        return 2

    if not os.path.isdir(store):
        print(f"[ERROR] vector store not found: {store}\n"
              f"        run build_vector_index.py first", file=sys.stderr)
        return 2

    db = lancedb.connect(store)
    if TABLE not in list_tables(db):
        print(f"[ERROR] table '{TABLE}' not found in {store}\n"
              f"        run build_vector_index.py first", file=sys.stderr)
        return 2

    table = db.open_table(TABLE)
    embedder = SentenceTransformer(model_name, device="cpu")

    print(f"[QUERY]   \"{query}\"")
    print(f"[MODEL]   {model_name} (local)")
    print(f"[MATCHES] {limit}")
    print("-" * 78)

    qvec = embedder.encode(query, convert_to_numpy=True).tolist()
    # Use the native query builder (no pylance dependency needed).
    q = table.search(qvec).limit(limit * 4)

    if provider:
        q = q.where(f"provider = '{provider}'")

    results = q.to_list()

    shown = 0
    for row in results:
        # LanceDB cosine distance: 0 = identical, 2 = opposite.
        dist = row.get("_distance")
        if dist is None:
            continue
        score = 1.0 - (dist / 2.0)
        if min_score is not None and score < min_score:
            continue

        shown += 1
        if shown > limit:
            shown -= 1
            break
        print(f"[MATCH {shown} - {row['provider'].upper()}] "
              f"cosine similarity {score:.4f} (distance {dist:.4f})")
        print(f"  Conversation: {row['conversation']}")
        print(f"  File: {row['path']}")
        snippet = " ".join(row["text"].split())
        print(f"  Snippet: \"{snippet[:200]}{'...' if len(snippet) > 200 else ''}\"")
        print("-" * 78)

    if shown == 0:
        print("(no matches)")
    else:
        print(f"\n[RESULT] {shown} matches across providers")
    return 0


def coverage_report(store: str) -> None:
    """Print indexed providers against the 8 TotalRecalls supports."""
    try:
        import lancedb
        db = lancedb.connect(store)
        if TABLE not in list_tables(db):
            return
        t = db.open_table(TABLE)
        provs = {r["provider"] for r in t.search().limit(None).to_list()}
    except Exception:  # noqa: BLE001
        return
    missing = sorted(set(SUPPORTED_PROVIDERS) - provs)
    print(f"\n[COVERAGE] {len(provs)}/{len(SUPPORTED_PROVIDERS)} providers indexed")
    if missing:
        print(f"[PENDING]  not yet exported: {', '.join(missing)}")


def sql_search(query: str, db_path: str, limit: int) -> int:
    if not os.path.isfile(db_path):
        print(f"[WARN] SQL container not found: {db_path}", file=sys.stderr)
        return 0
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    like = f"%{query}%"
    print("\n" + "=" * 78)
    print("SQL METADATA MATCHES (title / content LIKE)")
    print("=" * 78)
    cur.execute(
        """SELECT c.provider, c.title, c.created_at, c.message_count, m.role,
                  substr(m.content_md,1,120)
             FROM chats c JOIN messages m ON m.conv_key = c.conv_key
            WHERE c.title LIKE ? OR m.content_md LIKE ?
            ORDER BY c.created_at DESC LIMIT ?""",
        (like, like, limit),
    )
    rows = cur.fetchall()
    if not rows:
        print("(no SQL metadata matches)")
    for r in rows:
        print(f"  [{r[0].upper()}] {r[1] or '(untitled)'}")
        print(f"     {r[2]} | {r[3]} messages | {r[4]}: {r[5]}...")
    conn.close()
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Semantic search across all TotalRecalls provider histories.")
    ap.add_argument("query", help="natural language query")
    ap.add_argument("--store", default=DEFAULT_STORE)
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--limit", type=int, default=5)
    ap.add_argument("--provider", default=None, help="restrict to one provider")
    ap.add_argument("--min-score", type=float, default=None)
    ap.add_argument("--sql", action="store_true",
                    help="also query the SQLite metadata container")
    args = ap.parse_args()

    rc = vector_search(args.query, args.store, args.model, args.limit,
                       args.provider, args.min_score)
    coverage_report(args.store)
    if args.sql:
        sql_search(args.query, args.db, args.limit)
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
