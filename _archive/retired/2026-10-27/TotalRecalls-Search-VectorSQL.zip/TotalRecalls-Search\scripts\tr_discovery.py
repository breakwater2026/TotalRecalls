"""Shared discovery of TotalRecalls conversations in the export library.

The export layout has drifted over time and differs by provider:

  Current (chatgpt/claude/perplexity/qwen):
      Library/<provider>/<folder>/<conversation-dir>/conversation.{md,json}

  Memo's own snapshot (older/newer export style):
      Library/<provider>/<conversation>.md

  Gemini Takeout may nest one level deeper again.

Discovery is therefore layout-agnostic: walk the tree, find every
`conversation.json`, and derive the provider from the first path segment under
the library root. This means adding a provider requires no code change.
"""
from __future__ import annotations

import json
import os
import re

# All 8 providers TotalRecalls supports. Used for coverage reporting and for
# warning when an export appears under an unexpected name.
SUPPORTED_PROVIDERS = (
    "chatgpt",
    "claude",
    "perplexity",
    "gemini",
    "grok",
    "deepseek",
    "mistral",
    "qwen",
)

# Conversation dir names look like: "2026-10-20 14-02 -- Some Title -- a1b2c3d4"
DIR_SUFFIX_RE = re.compile(r"--\s*([0-9a-fA-F]{8})\s*$")

# Exporter artifact: the qwen exporter fails to resolve ids and writes zeros.
ZERO_SUFFIX_RE = re.compile(r"--\s*0{6,}\s*$")


def display_name(conv_dir: str) -> str:
    """Conversation label minus exporter artifacts.

    The qwen exporter writes a literal '-- 00000000' suffix on every directory
    because it cannot resolve the conversation id. Strip it. Providers with
    real ids (chatgpt, claude, perplexity, ...) keep their 8-hex suffix.
    """
    cleaned = ZERO_SUFFIX_RE.sub("", conv_dir).strip()
    return cleaned or conv_dir


def dir_identity(dirname: str) -> tuple[str | None, str | None]:
    """Extract (occurred_local, short_hash) from a conversation directory name."""
    m = DIR_SUFFIX_RE.search(dirname)
    short = m.group(1).lower() if m else None
    date_part = dirname.split(" -- ")[0].strip() if " -- " in dirname else ""
    return date_part or None, short


def find_conversations(library: str) -> list[dict]:
    """Locate every conversation in the library, whatever the nesting depth.

    Handles three real layouts:

      A) Library/<provider>/<folder>/<conv-dir>/conversation.json   (current)
      B) Library/<provider>/<file>.json + <file>.md                 (flat)
      C) Library/<provider>/<folder>/<sub>/<conv-dir>/...           (takeout)

    A flat layout is detected by scanning the provider directory's own files;
    anything nested is found by the walk below.
    """
    library = os.path.abspath(library)
    found: list[dict] = []
    seen_dirs: set[str] = set()

    # --- Pass 1: directories holding conversation.json at any depth ---
    for root, _dirs, files in os.walk(library):
        if "conversation.json" not in files:
            continue
        conv_dir = os.path.abspath(root)
        seen_dirs.add(conv_dir)
        found.append(_make_entry(library, conv_dir, os.path.basename(conv_dir)))

    # --- Pass 2: flat layout, files sitting directly in the provider dir ---
    for entry in sorted(os.listdir(library)):
        pdir = os.path.join(library, entry)
        if not os.path.isdir(pdir) or entry.startswith("."):
            continue
        # Only look one level down: a folder of conversations is handled above.
        for f in sorted(os.listdir(pdir)):
            fpath = os.path.join(pdir, f)
            if not os.path.isfile(fpath):
                continue
            lower = f.lower()
            if not lower.endswith(".json"):
                continue
            # Skip library-level metadata files, never conversations.
            if lower in ("manifest.json", "uuid_index.json", "index.json"):
                continue
            stem = f[:-5]
            found.append({
                "provider": entry,
                "folder": "",
                "conv_dir": pdir,
                "conv_name": stem,
                "json_path": fpath,
                "md_path": _paired_md(pdir, stem),
                "rel_dir": f"{entry}/{stem}".replace(os.sep, "/"),
            })

    # De-duplicate on json_path (a dir could be reached by both passes).
    unique: dict[str, dict] = {}
    for e in found:
        unique.setdefault(os.path.abspath(e["json_path"]), e)
    out = sorted(unique.values(), key=lambda d: (d["provider"], d["rel_dir"]))
    return out


def _make_entry(library: str, conv_dir: str, conv_name: str) -> dict:
    rel_dir = os.path.relpath(conv_dir, library)
    parts = rel_dir.split(os.sep)
    provider = parts[0] if parts else "unknown"
    folder = os.sep.join(parts[1:-1]) if len(parts) > 2 else ""
    return {
        "provider": provider,
        "folder": folder,
        "conv_dir": conv_dir,
        "conv_name": conv_name,
        "json_path": os.path.join(conv_dir, "conversation.json"),
        "md_path": _paired_md(conv_dir, "conversation"),
        "rel_dir": rel_dir.replace(os.sep, "/"),
    }


def _paired_md(directory: str, stem: str) -> str | None:
    """The markdown paired with a JSON stem, or None.

    Prefers '<stem>.md'; falls back to the single .md in the directory,
    skipping Word lock files and temporary artifacts.
    """
    preferred = os.path.join(directory, stem + ".md")
    if os.path.isfile(preferred):
        return preferred
    try:
        names = sorted(os.listdir(directory))
    except OSError:
        return None
    candidates = [
        f for f in names
        if f.lower().endswith(".md")
        and not f.startswith("~$")
        and not f.startswith(".~")
        and not f.endswith((".tmp", ".bak"))
    ]
    return os.path.join(directory, candidates[0]) if len(candidates) == 1 else None


def provider_coverage(convs: list[dict]) -> dict:
    """Count conversations per provider, plus what is missing from the 8."""
    counts: dict[str, int] = {}
    for c in convs:
        counts[c["provider"]] = counts.get(c["provider"], 0) + 1
    present = set(counts)
    return {
        "counts": counts,
        "present": sorted(present),
        "missing": sorted(set(SUPPORTED_PROVIDERS) - present),
        "unexpected": sorted(present - set(SUPPORTED_PROVIDERS)),
    }


def read_json(path: str) -> dict | None:
    """Load a conversation.json, tolerating unreadable/corrupt files."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None


def conversation_body(data: dict) -> dict:
    """Return the conversation dict, handling both nesting styles."""
    return data.get("conversation", data) if isinstance(data, dict) else {}
