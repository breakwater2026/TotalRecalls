#!/usr/bin/env python
"""Verify the installed TotalRecalls local search stack end to end.

Checks: dependency imports, SQLite row counts vs the library, LanceDB table
shape, embedding dimension agreement, and a live semantic query.

Exit 0 = everything checks out.

Run:  C:\\TotalRecalls-Search\\venv\\Scripts\\python.exe scripts\\verify_install.py
"""
from __future__ import annotations

import glob
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tr_discovery import (  # noqa: E402
    SUPPORTED_PROVIDERS,
    find_conversations,
    provider_coverage,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VENV_PY = os.path.join(ROOT, "venv", "Scripts", "python.exe")
DB = os.path.join(ROOT, "data", "totalrecalls_chats.db")
STORE = os.path.join(ROOT, "vector_store")
LIBRARY = r"C:\TotalRecalls-Downloads\Library"

failures: list[str] = []


def check(label: str, ok: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" — {detail}" if detail else ""))
    if not ok:
        failures.append(label)


def main() -> int:
    print("=" * 72)
    print("VERIFYING TOTALRECALLS LOCAL SEARCH STACK")
    print("=" * 72)

    # --- 1. environment ---
    print("\n[1] Environment")
    check("venv python exists", os.path.isfile(VENV_PY), VENV_PY)
    for mod in ("torch", "lancedb", "sentence_transformers", "pandas", "numpy"):
        try:
            __import__(mod)
            check(f"import {mod}", True)
        except ImportError as exc:
            check(f"import {mod}", False, str(exc))

    # --- 2. library ground truth ---
    print("\n[2] Library ground truth")
    convs = find_conversations(LIBRARY)
    cov = provider_coverage(convs)
    with_md = sum(1 for c in convs if c["md_path"] and os.path.isfile(c["md_path"]))
    print(f"       library: {len(convs)} conversations, {with_md} with paired .md")
    print(f"       providers: {cov['counts']}")
    if cov["missing"]:
        print(f"       pending: {', '.join(cov['missing'])}")
    check("library is non-empty", len(convs) > 0, f"{len(convs)} conversations")

    # --- 3. SQLite ---
    print("\n[3] SQLite container")
    check("db file exists", os.path.isfile(DB), DB)
    if os.path.isfile(DB):
        conn = sqlite3.connect(DB)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM chats")
        n_chats = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM messages")
        n_msgs = cur.fetchone()[0]
        print(f"       chats={n_chats}  messages={n_msgs}")
        check("chats == library conversations", n_chats == len(convs),
              f"db={n_chats} library={len(convs)}")

        cur.execute("SELECT provider, COUNT(*) FROM chats GROUP BY provider ORDER BY 2 DESC")
        print("       " + "  ".join(f"{p}={c}" for p, c in cur.fetchall()))

        # qwen must NOT be collapsed (the empty-id trap)
        cur.execute("SELECT COUNT(*), COUNT(DISTINCT conv_key) FROM chats WHERE provider='qwen'")
        q_rows, q_keys = cur.fetchone()
        check("qwen rows are distinct (empty-id trap)", q_rows == q_keys and q_rows > 0,
              f"{q_rows} rows / {q_keys} keys")

        # join integrity. A conversation may legitimately be empty (opened but
        # never used), so only conversations that claim messages must have rows.
        cur.execute("""SELECT COUNT(*) FROM chats c
                       LEFT JOIN messages m ON m.conv_key = c.conv_key
                       WHERE m.message_pk IS NULL AND c.message_count > 0""")
        orphans = cur.fetchone()[0]
        check("every non-empty chat has messages", orphans == 0, f"{orphans} orphans")

        cur.execute("SELECT COUNT(*) FROM chats WHERE message_count = 0")
        empty = cur.fetchone()[0]
        if empty:
            print(f"       {empty} conversation(s) are empty (no messages) — expected")

        # idempotency marker
        cur.execute("SELECT value FROM meta WHERE key='schema_version'")
        row = cur.fetchone()
        check("meta.schema_version present", row is not None, row[0] if row else "missing")
        conn.close()

    # --- 4. vector store ---
    print("\n[4] Vector store")
    check("vector_store dir exists", os.path.isdir(STORE), STORE)
    try:
        import lancedb
        db = lancedb.connect(STORE)
        tables = db.list_tables()
        names = list(tables.tables) if hasattr(tables, "tables") else list(tables)
        check("ai_knowledge_base table exists", "ai_knowledge_base" in names, str(names))
        if "ai_knowledge_base" in names:
            t = db.open_table("ai_knowledge_base")
            n = t.count_rows()
            print(f"       rows={n}  dim={t.schema.field('vector').type.list_size}")
            check("vector table non-empty", n > 0, f"{n} chunks")

            # every indexed chunk must trace back to a real md file
            paths = {r["path"] for r in t.search().limit(None).to_list()}
            missing = [p for p in paths if not os.path.isfile(p.replace("/", os.sep))]
            check("all chunk paths exist on disk", not missing,
                  f"{len(missing)} missing" if missing else f"{len(paths)} paths")

            # provider coverage: every provider present in the library must be indexed
            provs = {r["provider"] for r in t.search().limit(None).to_list()}
            print(f"       providers indexed: {sorted(provs)}")
            expected = set(cov["counts"])
            check("every library provider is indexed", expected <= provs,
                  f"missing {sorted(expected - provs)}" if expected - provs
                  else f"{len(provs)}/{len(SUPPORTED_PROVIDERS)} of 8 supported")
            if cov["missing"]:
                print(f"       pending export: {', '.join(cov['missing'])}")
    except Exception as exc:  # noqa: BLE001
        check("vector store readable", False, repr(exc))

    # --- 5. live query ---
    print("\n[5] Live semantic query")
    try:
        import lancedb
        from sentence_transformers import SentenceTransformer
        db = lancedb.connect(STORE)
        tables = db.list_tables()
        names = list(tables.tables) if hasattr(tables, "tables") else list(tables)
        if "ai_knowledge_base" in names:
            emb = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
            vec = emb.encode("pinescript trading strategy", convert_to_numpy=True).tolist()
            res = db.open_table("ai_knowledge_base").search(vec).limit(3).to_list()
            check("query returns results", len(res) > 0, f"{len(res)} matches")
            if res:
                top = res[0]
                print(f"       top: [{top['provider']}] {top['conversation'][:55]}")
                boilerplate = "**Provider:**" in top["text"][:200]
                check("top snippet is real content (not metadata)",
                       not boilerplate,
                       "snippet starts with boilerplate" if boilerplate else "clean")
    except Exception as exc:  # noqa: BLE001
        check("live query", False, repr(exc))

    # --- summary ---
    print("\n" + "=" * 72)
    if failures:
        print(f"RESULT: {len(failures)} CHECK(S) FAILED")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("RESULT: ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
