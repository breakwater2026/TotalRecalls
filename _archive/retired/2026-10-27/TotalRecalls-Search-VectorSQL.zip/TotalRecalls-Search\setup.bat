@echo off
REM TotalRecalls Local Search - one-time environment setup.
REM Run this once, from this folder, before building the indexes.
REM
REM   Usage:  setup.bat
REM
REM It creates an isolated Python environment in .\venv and installs the
REM packages the system needs. Nothing is uploaded; the only download is the
REM Python package set plus the embedding model (once, cached afterwards).

setlocal
cd /d "%~dp0"

echo.
echo === TotalRecalls Local Search - setup ===
echo.

REM --- pick a Python ---------------------------------------------------------
set PY=
for %%P in (python py) do (
    if not defined PY (
        where %%P >nul 2>&1 && set PY=%%P
    )
)
if not defined PY (
    echo [ERROR] Python was not found on your PATH.
    echo         Install Python 3.11+ from https://www.python.org/downloads/
    echo         and make sure "Add Python to PATH" is ticked, then re-run this.
    exit /b 1
)

echo [1/4] Using Python:
%PY% --version
echo.

REM --- create the virtual environment ---------------------------------------
if exist venv\Scripts\python.exe (
    echo [2/4] venv already exists - reusing it
) else (
    echo [2/4] Creating venv ...
    %PY% -m venv venv
    if errorlevel 1 (
        echo [ERROR] could not create the virtual environment.
        exit /b 1
    )
)
echo.

set VENV_PY=venv\Scripts\python.exe

REM --- install packages ------------------------------------------------------
echo [3/4] Installing packages (torch is large; this takes several minutes) ...
%VENV_PY% -m pip install --upgrade pip
%VENV_PY% -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] package installation failed. See the messages above.
    exit /b 1
)
echo.

REM --- build the two containers ---------------------------------------------
echo [4/4] Building the SQL container and the vector index ...
%VENV_PY% scripts\build_sql_container.py
if errorlevel 1 exit /b 1
%VENV_PY% scripts\build_vector_index.py
if errorlevel 1 exit /b 1
echo.

REM --- register the maintenance schedule -------------------------------------
echo Registering the automatic re-index task (every 24 hours at 03:00) ...
%VENV_PY% scripts\install_task.py
echo.

echo === Setup complete ===
echo.
echo Next steps:
echo   Search:      venv\Scripts\python.exe scripts\search_my_ai.py "your question"
echo   Chat UI:     venv\Scripts\python.exe scripts\chat_server.py  then open http://localhost:8000
echo   Notion:      venv\Scripts\python.exe scripts\export_for_notion.py
echo   Guide:       docs\TotalRecalls-Power-User-Guide.pdf
echo.
echo Full guide: docs\TotalRecalls-Power-User-Guide.pdf
echo.

endlocal
