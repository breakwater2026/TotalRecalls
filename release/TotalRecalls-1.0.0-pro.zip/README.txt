TotalRecalls 1.0.0 — Pro (Buyer Edition)
=========================================

Thank you for buying TotalRecalls. This is your unlocked app — there is
nothing left to activate.

WHAT THIS IS
------------
TotalRecalls is a Windows app that downloads your AI chat history to local
Markdown + JSON files you own. No installation, no account, no telemetry.
Just run TotalRecalls.exe.

WHAT YOU GET (Pro — everything unlocked)
----------------------------------------
- All 8 providers: Perplexity, ChatGPT, Claude, Gemini, Grok, DeepSeek,
  Mistral, Qwen
- Unlimited conversations per download
- Multi-format export (Markdown + JSON), provider-specific metadata,
  web-search result capture, per-conversation and bulk export
- No license key, no activation step. This build is permanently unlocked.

QUICK START
-----------
1. Run TotalRecalls.exe (no admin rights needed).
2. Pick a provider and follow the on-screen login steps (it opens your
   browser, you log in normally, and the app reads the session — it never
   sees your password).
3. Choose conversations and click Export. Your files land in
   TotalRecalls-download\ (or the folder you choose).

SUPPORTED PLATFORM
------------------
Windows 10 / 11, 64-bit. (macOS/Linux are on the roadmap.)

NOTES
-----
- TotalRecalls runs locally. Your chat data never leaves your machine
  except in the provider's own normal browser session.
- We are in beta. If something breaks, email support@totalrecalls.app —
  a human reads every message.

RESELLING / REDISTRIBUTING THIS BUILD
-------------------------------------
This EXE is the full, unlocked product. Please do not redistribute it —
it is licensed to you, one-time, not a subscription. If you received this
file expecting something else, email support@totalrecalls.app.
